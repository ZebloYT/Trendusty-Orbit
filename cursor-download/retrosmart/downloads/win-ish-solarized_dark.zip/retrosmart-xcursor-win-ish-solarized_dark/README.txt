Retrosmart cursors for Windows -- Retrosmart Win Ish Solarized_Dark
=================================================

To install:
  1. Right-click "install.inf" and choose "Install".
     (This registers "Retrosmart Win Ish Solarized_Dark" as a cursor scheme -- it does not
     apply it automatically.)
  2. Open Settings > Bluetooth & devices > Mouse > Additional mouse
     settings (or "Control Panel > Mouse"), go to the "Pointers" tab,
     and pick "Retrosmart Win Ish Solarized_Dark" from the Scheme dropdown, then Apply.

Besides the 15 files Windows uses for a scheme, every other Retrosmart
cursor is also included as a plain .cur/.ani file in this folder (named
after its role -- default, pointer, text, crosshair, zoom-in, ...), in
case you want to assign one manually (e.g. via a game or app that lets
you pick a custom cursor file, or via a registry/AutoHotkey script).

Note: this Windows build was generated automatically from the same
32px pixel-art source as the Linux/Xcursor theme; it hasn't been
tested on a real Windows machine, so if something looks off (wrong
hotspot, wrong role) please open an issue on the GitHub repo.
