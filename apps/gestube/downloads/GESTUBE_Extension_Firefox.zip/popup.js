document.getElementById('openYoutubeBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://www.youtube.com/' });
});
