// GESTUBE Background Service Worker
chrome.runtime.onInstalled.addListener(() => {
  console.log("GESTUBE Extension Installed Successfully!");
});

// Message listener for communications between popup, content, or background tasks
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "ping") {
    sendResponse({ status: "ok" });
  }
  return true;
});
