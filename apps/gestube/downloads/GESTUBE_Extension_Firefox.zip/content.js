﻿(function() {
                    try {
                        if (window.top !== window.self) return; // Prevent running in hidden iframes
                        if (window.gestubeInitialized) return;
                        window.gestubeInitialized = true;
                        // alert removed
                        
                        window.skipAdsEnabled = true; // default state
                        
                        // 1-Day Feedback Logic
                        const now = Date.now();
                        const firstRun = localStorage.getItem('gestube_first_run');
                        if (!firstRun) {
                            localStorage.setItem('gestube_first_run', now.toString());
                        } else {
                            const feedbackGiven = localStorage.getItem('gestube_feedback_given');
                            if (!feedbackGiven) {
                                const ONE_DAY_MS = 24 * 60 * 60 * 1000;
                                if (now - parseInt(firstRun, 10) > ONE_DAY_MS) {
                                    setTimeout(() => {
                                        const overlay = document.createElement('div');
                                        overlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.8); z-index: 99999; display: flex; justify-content: center; align-items: center; backdrop-filter: blur(5px);';
                                        
                                        const modal = document.createElement('div');
                                        modal.style.cssText = 'background: #181818; border-radius: 16px; padding: 30px; width: 450px; max-width: 90%; color: #fff; font-family: Roboto, sans-serif; box-shadow: 0 10px 30px rgba(0,0,0,0.8); text-align: center; border: 1px solid rgba(255,255,255,0.1);';
                                        
                                        const title = document.createElement('h2');
                                        title.textContent = 'Feedback Request';
                                        title.style.cssText = 'margin: 0 0 15px 0; font-size: 22px; font-weight: 600; color: #fff;';
                                        
                                        const text = document.createElement('p');
                                        text.textContent = 'We hope you are enjoying GESTUBE! Would you mind taking a quick moment to share your feedback or report any bugs to our developer?';
                                        text.style.cssText = 'margin: 0 0 30px 0; font-size: 15px; line-height: 1.5; color: #aaa;';
                                        
                                        const btnContainer = document.createElement('div');
                                        btnContainer.style.cssText = 'display: flex; gap: 15px; justify-content: center;';
                                        
                                        const cancelBtn = document.createElement('button');
                                        cancelBtn.textContent = 'Not Now';
                                        cancelBtn.style.cssText = 'padding: 12px 24px; border: none; border-radius: 20px; background: rgba(255,255,255,0.1); color: #fff; cursor: pointer; font-weight: 600; font-size: 14px; flex: 1; transition: background 0.2s;';
                                        cancelBtn.onmouseover = () => cancelBtn.style.background = 'rgba(255,255,255,0.2)';
                                        cancelBtn.onmouseout = () => cancelBtn.style.background = 'rgba(255,255,255,0.1)';
                                        cancelBtn.onclick = () => {
                                            document.body.removeChild(overlay);
                                            localStorage.setItem('gestube_feedback_given', 'true');
                                        };
                                        
                                        const continueBtn = document.createElement('button');
                                        continueBtn.textContent = 'Send Feedback';
                                        continueBtn.style.cssText = 'padding: 12px 24px; border: none; border-radius: 20px; background: #3ea6ff; color: #000; cursor: pointer; font-weight: 600; font-size: 14px; flex: 1; transition: background 0.2s;';
                                        continueBtn.onmouseover = () => continueBtn.style.background = '#65b8ff';
                                        continueBtn.onmouseout = () => continueBtn.style.background = '#3ea6ff';
                                        continueBtn.onclick = () => {
                                            document.body.removeChild(overlay);
                                            localStorage.setItem('gestube_feedback_given', 'true');
                                            window.open('https://mail.google.com/mail/?view=cm&fs=1&to=conputerit2008@gmail.com', '_blank');
                                        };
                                        
                                        btnContainer.appendChild(cancelBtn);
                                        btnContainer.appendChild(continueBtn);
                                        
                                        modal.appendChild(title);
                                        modal.appendChild(text);
                                        modal.appendChild(btnContainer);
                                        overlay.appendChild(modal);
                                        
                                        document.body.appendChild(overlay);
                                    }, 2000);
                                }
                            }
                        }
                        window.autoScrollShortsEnabled = true;
                        window.autoSkipShortAdsEnabled = true;
                        window.gestubeLastScrollTime = 0;
                        window.gestubeLastVideoTime = 0;
                    const savedLongSettings = localStorage.getItem('gestube_long_settings');
                    window.gestubeLongSettings = savedLongSettings ? JSON.parse(savedLongSettings) : {
                        sponsorBlock: false,
                        focusMode: false,
                        quality: 'auto',
                        speed: 1.0,
                        hideComments: false,
                        hideSidebar: false,
                        hideChat: false,
                        volumeBoost: false,
                        autoResume: false
                    };
                    const savedExtensions = localStorage.getItem('gestube_extensions_state');
                    window.gestubeExtensions = savedExtensions ? JSON.parse(savedExtensions) : {
                        ryd: false,
                        vidiq: false,
                        pip: false,
                        cinematic: false
                    };
                    window.gestubeNiches = {
                        gaming: { _all: false, minecraft: false, roblox: false, gta: false, fortnite: false, valorant: false, cod: false, freefire: false },
                        music: { _all: false, pop: false, rap: false, remix: false, concert: false, cover: false, phonk: false },
                        news: { _all: false, politics: false, podcast: false, daily: false },
                        sports: { _all: false, nba: false, nfl: false, soccer: false },
                        cringe: { _all: false, sound: false, sub: false, viral: false, stupid: false },
                        edits: { _all: false, football: false, nfl_edit: false, random: false, roblox_edit: false, minecraft_edit: false, newvsold: false, freefire_edit: false },
                        memes: { _all: false, reaction: false, photo: false }
                    };
                    
                    // Load persisted state if exists
                    const savedNiches = localStorage.getItem('gestube_niches_state');
                    if (savedNiches) {
                        try {
                            const parsed = JSON.parse(savedNiches);
                            Object.keys(parsed).forEach(k => {
                                if (window.gestubeNiches[k]) {
                                    Object.assign(window.gestubeNiches[k], parsed[k]);
                                }
                            });
                        } catch (e) {}
                    }
                    
                    window.gestubeIgnoredChannels = JSON.parse(localStorage.getItem('gestube_ignored_channels') || '[]');
                    window.gestubeIgnoredSounds = JSON.parse(localStorage.getItem('gestube_ignored_sounds') || '[]');
                    
                    const initInterval = setInterval(() => {
                        try {
                            if (document.head && document.body) {
                                clearInterval(initInterval);
                            
                            // 1. Inject Styles
                                                        const style = document.createElement('style');
                            style.id = 'gestube-style';
                            style.textContent = `
                                                                  #gestube-sidebar {
                                      position: fixed;
                                      top: 30%;
                                      left: 0;
                                      display: flex;
                                      z-index: 9999999;
                                      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                                      height: auto;
                                      border-top-right-radius: 15px;
                                      border-bottom-right-radius: 15px;
                                      overflow: hidden;
                                  }
                                
                                #gestube-handle {
    width: 44px;
    background: linear-gradient(135deg, #ff0033, #b30024);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    min-height: 95px;
    border-top-right-radius: 16px;
    border-bottom-right-radius: 16px;
    box-shadow: 2px 4px 14px rgba(0,0,0,0.85);
    user-select: none;
    -webkit-user-select: none;
    touch-action: manipulation;
    position: relative;
    z-index: 99999999;
}
                                
                                #gestube-handle-icon {
                                    color: gray;
                                    font-size: 24px;
                                    font-weight: bold;
                                }
                                
                                #gestube-panel { width: 250px; background: #2C2C2C; overflow: hidden; transition: width 0.2s cubic-bezier(0.25, 1, 0.5, 1); display: flex; flex-direction: column; }
                                
                                #gestube-panel {
    width: 290px;
    max-height: 85vh;
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
    background: #1c1c1c;
    border: 1px solid #333;
    border-left: none;
    border-top-right-radius: 16px;
    border-bottom-right-radius: 16px;
    box-shadow: 4px 6px 22px rgba(0,0,0,0.9);
    display: flex;
    flex-direction: column;
}
#gestube-sidebar.collapsed #gestube-panel {
    display: none !important;
}

                                .gestube-panel-content {
                                    padding: 20px;
                                    width: 210px;
                                    display: flex;
                                    flex-direction: column;
                                }
                                
                                .gestube-menu-title {
                                    font-size: 18px;
                                    font-weight: bold;
                                    color: cyan;
                                    margin-bottom: 20px;
                                }

                                .gestube-btn {
                                    background: #333;
                                    color: white;
                                    border: 1px solid #444;
                                    padding: 10px;
                                    margin-bottom: 10px;
                                    cursor: pointer;
                                    text-align: left;
                                    font-weight: bold;
                                    font-size: 14px;
                                    border-radius: 4px;
                                    transition: background 0.2s;
                                }
                                .gestube-btn:hover { background: #444; }
                                
                                .gestube-btn-gold { background: gold; color: black; border: none; }
                                .gestube-btn-gold:hover { background: #FFD700; }
                                
                                                                  #gestube-home-modal {
                                      display: none;
                                      position: fixed;
                                      top: 50px;
                                      left: 50px;
                                      width: 600px;
                                      height: 500px;
                                      background: #222;
                                      color: white;
                                      z-index: 999999;
                                      border-radius: 8px;
                                      box-shadow: 0 4px 20px rgba(0,0,0,0.5);
                                      flex-direction: column;
                                      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                                      border: 1px solid #444;
                                  }
                                  #gestube-modal-header {
                                      padding: 15px 20px;
                                      background: #1A1A1A;
                                      display: flex;
                                      justify-content: space-between;
                                      align-items: center;
                                      border-bottom: 1px solid #333;
                                      cursor: move;
                                      border-top-left-radius: 8px;
                                      border-top-right-radius: 8px;
                                  }
                                  #gestube-modal-content {
                                      display: flex;
                                      flex-direction: row;
                                      flex: 1;
                                      overflow: hidden;
                                      background: #222;
                                      padding: 20px;
                                      overflow-y: auto;
                                  }
                                  /* Modal CSS from old code */
                                #gestube-modal-overlay {
                                    position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; 
                                    background: rgba(0,0,0,0.8); z-index: 99999999; display: flex; 
                                    justify-content: center; align-items: center; backdrop-filter: blur(5px);
                                }
                                #gestube-dl-modal {
                                    background: #181818; border-radius: 16px; padding: 30px; 
                                    width: 400px; max-width: 90%; color: #fff; box-shadow: 0 10px 30px rgba(0,0,0,0.8); 
                                    text-align: center; border: 1px solid rgba(255,255,255,0.1);
                                }
                                .gestube-dl-btn {
                                    padding: 12px; border: none; border-radius: 8px; 
                                    background: rgba(255,255,255,0.1); color: #fff; cursor: pointer; 
                                    font-weight: 600; font-size: 14px; transition: background 0.2s; margin-bottom: 10px; width: 100%;
                                }
                                .gestube-dl-btn:hover { background: rgba(255,255,255,0.2); }
                            `;
                            document.head.appendChild(style);

                            // Sidebar UI
                            const sidebar = document.createElement('div');
                            sidebar.id = 'gestube-sidebar';
                              sidebar.classList.add('collapsed');
                            
                            const handle = document.createElement('div');
                            handle.id = 'gestube-handle';
                            const icon = document.createElement('div');
                            icon.id = 'gestube-handle-icon';
                            icon.textContent = '\u2630';
                            handle.appendChild(icon);
                            
                            const panel = document.createElement('div');
                            panel.id = 'gestube-panel';
                            
                            const sidebarContent = document.createElement('div');
                            sidebarContent.className = 'gestube-panel-content';
                            
                            const closeSideBtn = document.createElement('button');
                            closeSideBtn.id = 'gestube-sidebar-close-btn';
                            closeSideBtn.textContent = '\u2715';
                            closeSideBtn.style.cssText = 'position: absolute; top: 12px; right: 12px; background: #e62117; color: #ffffff; border: none; font-size: 16px; font-weight: bold; width: 34px; height: 34px; border-radius: 17px; cursor: pointer; display: flex; align-items: center; justify-content: center; z-index: 999999;';
                            closeSideBtn.onclick = (e) => collapseSidebar(e);
                            closeSideBtn.ontouchend = (e) => collapseSidebar(e);
                            sidebarContent.style.position = 'relative';
                            sidebarContent.appendChild(closeSideBtn);

                            const title = document.createElement('div');
                            title.className = 'gestube-menu-title';
                            title.textContent = 'MENU';
                            sidebarContent.appendChild(title);

                            const homeBtn = document.createElement('button');
                            homeBtn.className = 'gestube-btn';
                            homeBtn.textContent = 'Home';
                            sidebarContent.appendChild(homeBtn);

                            const downloadBtn = document.createElement('button');
                            downloadBtn.className = 'gestube-btn';
                            downloadBtn.textContent = 'Download Video';
                            downloadBtn.onclick = () => { if (!window.location.pathname.startsWith('/watch') && !window.location.pathname.startsWith('/shorts')) { alert('No video is open to download!'); return; }
                                const overlay = document.createElement('div');
                                overlay.id = 'gestube-modal-overlay';
                                const modal = document.createElement('div');
                                modal.id = 'gestube-dl-modal';
                                
                                const modalTitle = document.createElement('h2');
                                modalTitle.textContent = 'Select Quality';
                                modalTitle.style.cssText = 'margin: 0 0 15px 0; font-size: 22px; font-weight: 600; color: #fff;';
                                
                                const createQualityBtn = (label, format) => {
                                    const btn = document.createElement('button');
                                    btn.className = 'gestube-dl-btn';
                                    btn.textContent = label;
                                    btn.onclick = () => {
                                        document.body.removeChild(overlay);
                                        window.location.href = 'gestube://' + ('DOWNLOAD:' + window.location.href + '|' + format);
                                    };
                                    return btn;
                                };
                                
                                modal.appendChild(modalTitle);
                                modal.appendChild(createQualityBtn('1080p Full HD', '1080'));
                                modal.appendChild(createQualityBtn('4K Ultra HD', '2160'));
                                modal.appendChild(createQualityBtn('8K Resolution', '4320'));
                                
                                const closeBtn = document.createElement('button');
                                closeBtn.className = 'gestube-dl-btn';
                                closeBtn.style.background = '#8B0000';
                                closeBtn.textContent = 'X';
                                closeBtn.onclick = () => document.body.removeChild(overlay);
                                modal.appendChild(closeBtn);
                                
                                overlay.appendChild(modal);
                                document.body.appendChild(overlay);
                            };
                            sidebarContent.appendChild(downloadBtn);

                            const dustChannelBtn = document.createElement('button');
                            dustChannelBtn.id = 'gestube-dust-channel-btn';
                            dustChannelBtn.className = 'gestube-btn gestube-btn-gold';
                            dustChannelBtn.textContent = 'Dust Channel';
                            dustChannelBtn.onclick = () => {
                                const channelElem = document.querySelector('ytd-watch-metadata #channel-name a');
                                if (channelElem && channelElem.textContent) {
                                    const cname = channelElem.textContent.trim().toLowerCase();
                                    if (!window.gestubeIgnoredChannels.includes(cname)) {
                                        window.gestubeIgnoredChannels.push(cname);
                                        localStorage.setItem('gestube_ignored_channels', JSON.stringify(window.gestubeIgnoredChannels));
                                    }
                                    const vid = document.querySelector('ytd-watch-flexy video');
                                    if (vid) {
                                        vid.pause();
                                        vid.style.filter = 'blur(20px)';
                                    }
                                    alert('Channel ""' + cname + '"" has been dusted. You will no longer see its videos.');
                                } else {
                                    alert('Could not find channel name. Make sure you are watching a video.');
                                }
                            };
                            sidebarContent.appendChild(dustChannelBtn);

                            panel.appendChild(sidebarContent);
                            sidebar.appendChild(handle);
                            sidebar.appendChild(panel);
                            // Button removed temporarily

                            const createCheckbox = (id, labelText, isChecked) => {
                                const label = document.createElement('label');
                                label.className = 'gestube-checkbox-container';
                                
                                const checkbox = document.createElement('input');
                                checkbox.type = 'checkbox';
                                checkbox.id = id;
                                checkbox.checked = isChecked;
                                
                                const span = document.createElement('span');
                                span.textContent = labelText;
                                
                                label.appendChild(checkbox);
                                label.appendChild(span);
                                return label;
                            };

                            // Standard Section (Inside Sidebar)
                            const standardSec = document.createElement('div');
                            standardSec.id = 'gestube-standard-section';
                            standardSec.style.cssText = 'width: 100%;';

                            standardSec.appendChild(createCheckbox('gestube-skip-ads', 'Skip Ads (Premium)', true));
                            const standardDesc = document.createElement('div');
                            standardDesc.className = 'gestube-desc';
                            standardDesc.style.textAlign = 'left';
                            standardDesc.textContent = 'Auto skip and fast-forward standard video ads.';
                            standardSec.appendChild(standardDesc);
                            
                            sidebarContent.appendChild(standardSec);

                            // Shorts Section (Inside Sidebar)
                            const shortsSec = document.createElement('div');
                            shortsSec.id = 'gestube-shorts-section';
                                                          shortsSec.style.cssText = 'width: 100%; display: none; position: relative; overflow: hidden; padding: 10px 0; border-radius: 8px;';
                              
                              const blockOverlay = document.createElement('div');
                              blockOverlay.style.cssText = 'position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.6); z-index: 9; border-radius: 8px; cursor: not-allowed;';
                              shortsSec.appendChild(blockOverlay);
                              
                              const tape1 = document.createElement('div');
                              tape1.style.cssText = 'position: absolute; top: 40%; left: -20%; right: -20%; height: 35px; background: repeating-linear-gradient(45deg, #FFD700, #FFD700 15px, #000 15px, #000 30px); opacity: 0.95; z-index: 10; display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 900; font-size: 16px; letter-spacing: 2px; text-shadow: 2px 2px 0 #000, -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000; transform: translateY(-50%) rotate(-10deg); box-shadow: 0 4px 10px rgba(0,0,0,0.7); border: 2px solid #000; border-left: none; border-right: none;';
                              tape1.textContent = 'COMMING SOON';
                              
                              const tape2 = document.createElement('div');
                              tape2.style.cssText = 'position: absolute; top: 60%; left: -20%; right: -20%; height: 35px; background: repeating-linear-gradient(45deg, #FFD700, #FFD700 15px, #000 15px, #000 30px); opacity: 0.95; z-index: 10; display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 900; font-size: 16px; letter-spacing: 2px; text-shadow: 2px 2px 0 #000, -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000; transform: translateY(-50%) rotate(10deg); box-shadow: 0 4px 10px rgba(0,0,0,0.7); border: 2px solid #000; border-left: none; border-right: none;';
                              tape2.textContent = 'COMMING SOON';
                              
                              shortsSec.appendChild(tape1);
                              shortsSec.appendChild(tape2);

                            shortsSec.appendChild(createCheckbox('gestube-scroll-shorts', 'Auto Scroll Shorts', true));
                            shortsSec.appendChild(createCheckbox('gestube-skip-short-ads', 'Auto Skip Short Ads', true));
                            
                            // (We will append optimizerContainer and visualBtn here later in the file once they are defined)
                            panel.appendChild(sidebarContent);
                            document.body.appendChild(sidebar);
                            // hoverArea removed

                            // 3. Create Home Modal HTML Elements
                            const modal = document.createElement('div');
                            modal.id = 'gestube-home-modal';

                            // Header (Draggable)
                            const modalHeader = document.createElement('div');
                            modalHeader.id = 'gestube-modal-header';
                            
                            const headerTitle = document.createElement('div');
                            headerTitle.textContent = 'Home Screen';
                            headerTitle.style.cssText = 'font-size: 18px; font-weight: bold;';
                            modalHeader.appendChild(headerTitle);

                            const closeBtn = document.createElement('button');
                            closeBtn.id = 'gestube-modal-close';
                            closeBtn.className = 'gestube-btn';
                            closeBtn.textContent = 'X';
                            closeBtn.style.cssText = 'padding: 6px 12px; font-size: 12px; border-radius: 8px;';
                            modalHeader.appendChild(closeBtn);
                            
                            modal.appendChild(modalHeader);
                            
                            // Content Area
                            const modalContent = document.createElement('div');
                            modalContent.id = 'gestube-modal-content';
                            modal.appendChild(modalContent);

                            // --- View 1: Home View ---
                            const homeView = document.createElement('div');
                            homeView.id = 'gestube-home-view';
                            
                            const welcomeTitle = document.createElement('div');
                            welcomeTitle.textContent = 'Welcome to GESTUBE';
                            welcomeTitle.style.cssText = 'font-size: 28px; font-weight: bold; margin-bottom: 25px; text-align: center;';
                            homeView.appendChild(welcomeTitle);

                            const btnWrapper = document.createElement('div');
                            btnWrapper.style.cssText = 'display: flex; flex-direction: column; gap: 15px; align-items: center;';

                            const settingsBtn = document.createElement('button');
                            settingsBtn.className = 'gestube-btn';
                            settingsBtn.textContent = 'Settings';
                            settingsBtn.style.cssText = 'width: 200px; padding: 12px; font-size: 16px;';
                            
                            const extensionsBtn = document.createElement('button');
                            extensionsBtn.className = 'gestube-btn';
                            extensionsBtn.textContent = 'Extension Store';
                            extensionsBtn.style.cssText = 'width: 200px; padding: 12px; font-size: 16px; background: #6a0dad;'; // Purple theme
                            
                            const downloadsBtn = document.createElement('button');
                            downloadsBtn.className = 'gestube-btn';
                            downloadsBtn.textContent = 'Offline Downloads';
                            downloadsBtn.style.cssText = 'width: 200px; padding: 12px; font-size: 16px; background: #0078d7;';

                            const binsBtn = document.createElement('button');
                            binsBtn.className = 'gestube-btn';
                            binsBtn.textContent = 'Dust Bins';
                            binsBtn.style.cssText = 'width: 200px; padding: 12px; font-size: 16px; background: #8B0000;';

                            btnWrapper.appendChild(settingsBtn);
                            btnWrapper.appendChild(extensionsBtn);
                            btnWrapper.appendChild(downloadsBtn);
                            btnWrapper.appendChild(binsBtn);
                            homeView.appendChild(btnWrapper);

                            modalContent.appendChild(homeView);

                            // --- View 3: Downloads View ---
                            const dlView = document.createElement('div');
                            dlView.id = 'gestube-downloads-view';
                            dlView.style.display = 'none';
                            
                            const dlBackBtn = document.createElement('button');
                            dlBackBtn.className = 'gestube-btn';
                            dlBackBtn.textContent = '< Back';
                            dlBackBtn.style.cssText = 'margin-bottom: 20px; font-size: 14px;';
                            dlBackBtn.onclick = () => {
                                dlView.style.display = 'none';
                                homeView.style.display = 'block';
                            };
                            dlView.appendChild(dlBackBtn);
                            
                            const dlTitle = document.createElement('div');
                            dlTitle.textContent = 'Offline Downloads';
                            dlTitle.style.cssText = 'font-size: 24px; font-weight: bold; margin-bottom: 20px;';
                            dlView.appendChild(dlTitle);
                            
                            const openFolderBtn = document.createElement('button');
                            openFolderBtn.textContent = 'Open Downloads Folder';
                            openFolderBtn.style.cssText = 'background: #282828; color: #fff; border: 1px solid #444; padding: 10px 15px; border-radius: 8px; cursor: pointer; margin-bottom: 20px; font-weight: bold; width: 100%; transition: background 0.2s;';
                            openFolderBtn.onmouseover = () => openFolderBtn.style.background = '#383838';
                            openFolderBtn.onmouseout = () => openFolderBtn.style.background = '#282828';
                            openFolderBtn.onclick = () => window.location.href = 'gestube://' + ('OPEN_DOWNLOAD_FOLDER');
                            dlView.appendChild(openFolderBtn);

                            const dlList = document.createElement('div');
                            dlList.id = 'gestube-dl-list';
                            dlList.style.cssText = 'display: flex; flex-direction: column; gap: 10px; max-height: 300px; overflow-y: auto; text-align: left;';
                            dlView.appendChild(dlList);
                            
                            modalContent.appendChild(dlView);

                            downloadsBtn.onclick = () => {
                                homeView.style.display = 'none';
                                dlView.style.display = 'block';
                                dlList.textContent = '';
                                const loading = document.createElement('div');
                                loading.textContent = 'Loading downloads...';
                                loading.style.cssText = 'color:#aaa; text-align: center;';
                                dlList.appendChild(loading);
                                window.location.href = 'gestube://' + ('GET_DOWNLOADS');
                            };
                            
                                                        window.showDownloadProgress = (text) => {
                                let p = document.getElementById('gestube-dl-progress');
                                if (!p) {
                                    p = document.createElement('div');
                                    p.id = 'gestube-dl-progress';
                                    p.style.cssText = 'position: fixed; bottom: 20px; right: 20px; background: rgba(0,0,0,0.8); color: #fff; padding: 15px; border-radius: 8px; z-index: 99999999; font-family: Roboto, sans-serif; box-shadow: 0 5px 15px rgba(0,0,0,0.5); border: 1px solid #333; width: 300px; display: flex; flex-direction: column; gap: 10px;';
                                    const title = document.createElement('div'); title.textContent = 'Downloading...'; title.style.cssText = 'font-weight: bold; font-size: 14px;'; p.appendChild(title);
                                    const barContainer = document.createElement('div'); barContainer.style.cssText = 'width: 100%; height: 6px; background: #333; border-radius: 3px; overflow: hidden;';
                                    const bar = document.createElement('div'); bar.id = 'gestube-dl-bar'; bar.style.cssText = 'width: 0%; height: 100%; background: #3ea6ff; transition: width 0.2s;'; barContainer.appendChild(bar); p.appendChild(barContainer);
                                    const status = document.createElement('div'); status.id = 'gestube-dl-status'; status.style.cssText = 'font-size: 12px; color: #aaa; word-break: break-all;'; p.appendChild(status);
                                    document.body.appendChild(p);
                                }
                                const statusEl = document.getElementById('gestube-dl-status');
                                const barEl = document.getElementById('gestube-dl-bar');
                                if (statusEl) statusEl.textContent = text;
                                const match = text.match(/\[download\]\s+([\d\.]+)%/);
                                if (match && barEl) barEl.style.width = match[1] + '%';
                            };
                            window.hideDownloadProgress = () => {
                                const p = document.getElementById('gestube-dl-progress');
                                if (p) p.remove();
                            };
                            window.renderDownloadsTab = () => {
                                    dlList.textContent = '';
                                    if (!window.gestubeDownloads || window.gestubeDownloads.length === 0) {
                                        dlTitle.textContent = 'Offline Downloads (0)';
                                        const empty = document.createElement('div');
                                        empty.textContent = 'No downloads found yet! Use the  Download Video button in the sidebar to save videos for offline viewing.';
                                        empty.style.cssText = 'color:#aaa; text-align: center;';
                                        dlList.appendChild(empty);
                                        return;
                                    }
                                    
                                    dlTitle.textContent = 'Offline Downloads (' + window.gestubeDownloads.length + ')';
                                    
                                    window.gestubeDownloads.forEach(file => {
                                        const item = document.createElement('div');
                                        item.style.cssText = 'background: rgba(255,255,255,0.05); padding: 10px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1); display: flex; align-items: center; gap: 15px; cursor: pointer; transition: background 0.2s;';
                                        
                                        const thumbContainer = document.createElement('div');
                                        thumbContainer.style.cssText = 'width: 120px; height: 68px; background: #000; border-radius: 6px; overflow: hidden; display: flex; align-items: center; justify-content: center; flex-shrink: 0;';
                                        
                                        const videoForThumb = document.createElement('video');
                                        videoForThumb.src = 'https://gestube.local/' + encodeURIComponent(file) + '#t=5';
                                        videoForThumb.preload = 'metadata';
                                        videoForThumb.muted = true;
                                        videoForThumb.style.cssText = 'width: 100%; height: 100%; object-fit: cover;';
                                        
                                        thumbContainer.appendChild(videoForThumb);
                                        
                                        const titleSpan = document.createElement('span');
                                        titleSpan.textContent = file.replace('.mp4', '');
                                        titleSpan.style.cssText = 'font-weight: bold; font-size: 14px; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; flex-grow: 1;';
                                        
                                        item.appendChild(thumbContainer);
                                                                                  item.appendChild(titleSpan);
                                          
                                          const deleteBtn = document.createElement('button');
                                          deleteBtn.textContent = 'Delete';
                                          deleteBtn.style.cssText = 'background: #cc0000; border: none; border-radius: 4px; color: #fff; padding: 5px 10px; cursor: pointer; z-index: 10;';
                                          deleteBtn.onclick = (e) => {
                                              e.stopPropagation();
                                              try { window.chrome.webview.postMessage('DELETE_DOWNLOAD:' + file); } catch(err) {}
                                              item.remove();
                                              if (window.gestubeDownloads) {
                                                  window.gestubeDownloads = window.gestubeDownloads.filter(f => f !== file);
                                                  dlTitle.textContent = 'Offline Downloads (' + window.gestubeDownloads.length + ')';
                                              }
                                          };
                                          item.appendChild(deleteBtn);
                                        
                                        item.onmouseover = () => item.style.background = 'rgba(255,255,255,0.1)';
                                        item.onmouseout = () => item.style.background = 'rgba(255,255,255,0.05)';
                                        item.onclick = () => {
                                            const overlay = document.createElement('div');
                                            overlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: #000; z-index: 9999999; display: flex; flex-direction: column;';
                                            
                                            const header = document.createElement('div');
                                            header.style.cssText = 'padding: 15px 20px; background: #181818; border-bottom: 1px solid #333; display: flex; justify-content: space-between; align-items: center;';
                                            
                                            const titleText = document.createElement('span');
                                            titleText.textContent = file;
                                            titleText.style.cssText = 'color: #fff; font-size: 16px; font-weight: bold; font-family: Roboto, sans-serif;';
                                            
                                            const closeVideo = document.createElement('button');
                                            closeVideo.textContent = ' Close';
                                            closeVideo.style.cssText = 'background: rgba(255,255,255,0.1); color: #fff; border: none; padding: 8px 15px; border-radius: 20px; cursor: pointer; font-family: Roboto, sans-serif;';
                                            closeVideo.onclick = () => document.body.removeChild(overlay);
                                            
                                            header.appendChild(titleText);
                                            header.appendChild(closeVideo);
                                            
                                            const vidContainer = document.createElement('div');
                                            vidContainer.style.cssText = 'flex-grow: 1; display: flex; justify-content: center; align-items: center; padding: 20px;';
                                            
                                            const vid = document.createElement('video');
                                            vid.src = 'https://gestube.local/' + encodeURIComponent(file);
                                            vid.controls = true;
                                            vid.autoplay = true;
                                            vid.style.cssText = 'max-width: 100%; max-height: 100%; outline: none; border-radius: 12px;';
                                            
                                            vidContainer.appendChild(vid);
                                            overlay.appendChild(header);
                                            overlay.appendChild(vidContainer);
                                            document.body.appendChild(overlay);
                                        };
                                        dlList.appendChild(item);
                                    });
                                };

                            // --- View 4: Extension Store View ---
                            const extView = document.createElement('div');
                            extView.id = 'gestube-extensions-view';
                            extView.style.cssText = 'display: none; flex-direction: column; flex: 1;';
                            
                            const extBackBtn = document.createElement('button');
                            extBackBtn.className = 'gestube-btn';
                            extBackBtn.textContent = '< Back';
                            extBackBtn.style.cssText = 'margin-bottom: 20px; font-size: 14px;';
                            extBackBtn.onclick = () => {
                                extView.style.display = 'none';
                                homeView.style.display = 'block';
                            };
                            extView.appendChild(extBackBtn);

                            const extTitle = document.createElement('div');
                            extTitle.textContent = ' Extension Store';
                            extTitle.style.cssText = 'font-size: 24px; font-weight: bold; margin-bottom: 15px; color: #b366ff;';
                            extView.appendChild(extTitle);

                            // Tabs
                            const extTabs = document.createElement('div');
                            extTabs.style.cssText = 'display: flex; gap: 10px; margin-bottom: 20px;';
                            
                            const browseTabBtn = document.createElement('button');
                            browseTabBtn.textContent = 'Browse';
                            browseTabBtn.style.cssText = 'flex: 1; padding: 10px; border: none; border-radius: 8px; background: #6a0dad; color: white; cursor: pointer; font-weight: bold; transition: background 0.2s;';
                            
                            const installedTabBtn = document.createElement('button');
                            installedTabBtn.textContent = 'Installed';
                            installedTabBtn.style.cssText = 'flex: 1; padding: 10px; border: none; border-radius: 8px; background: #282828; color: white; cursor: pointer; font-weight: bold; transition: background 0.2s;';

                            extTabs.appendChild(browseTabBtn);
                            extTabs.appendChild(installedTabBtn);
                            extView.appendChild(extTabs);

                            // Content areas
                            const browseArea = document.createElement('div');
                            browseArea.style.cssText = 'display: flex; flex-direction: column; gap: 10px; flex: 1; overflow-y: auto; padding-right: 5px;';
                            
                            const installedArea = document.createElement('div');
                            installedArea.style.cssText = 'display: none; flex-direction: column; gap: 10px; flex: 1; overflow-y: auto; padding-right: 5px;';

                            extView.appendChild(browseArea);
                            extView.appendChild(installedArea);

                            // Tab switching
                            browseTabBtn.onclick = () => {
                                browseTabBtn.style.background = '#6a0dad';
                                installedTabBtn.style.background = '#282828';
                                browseArea.style.display = 'flex';
                                installedArea.style.display = 'none';
                            };
                            installedTabBtn.onclick = () => {
                                installedTabBtn.style.background = '#6a0dad';
                                browseTabBtn.style.background = '#282828';
                                installedArea.style.display = 'flex';
                                browseArea.style.display = 'none';
                            };

                            const availableExtensions = [
                                { id: 'ryd', name: 'Return YouTube Dislike', desc: 'Restores the exact dislike count on videos using the RYD API.', icon: '' },
                                { id: 'vidiq', name: 'VidIQ Lite', desc: 'Adds a stats sidebar with Views/Hr, Engagement Rate & metrics.', icon: '' },
                                { id: 'pip', name: 'Picture-in-Picture Mode', desc: 'Adds a pop-out video button for multitasking over other windows.', icon: '' },
                                { id: 'cinematic', name: 'Cinematic Lighting+', desc: 'Extends ambient mode lighting to the full background.', icon: '' },
                                { id: 'loop', name: 'Auto-Loop Videos', desc: 'Automatically loops every video so they replay infinitely.', icon: '' },
                                { id: 'shortsblock', name: 'Shorts Blocker', desc: 'Completely hides YouTube Shorts from the feed and sidebar.', icon: '' },
                                { id: 'purpletheme', name: 'GESTUBE Purple Theme', desc: 'Overhauls YouTube to match the GESTUBE purple aesthetics.', icon: '' },
                                { id: 'autohd', name: 'Auto 4K/HD', desc: 'Forces the video player to default to the highest possible quality.', icon: '' },
                                { id: 'sponsorblock_ext', name: 'SponsorBlock Engine', desc: 'Auto-skips sponsored segments, intros, and outros natively.', icon: '' },
                                { id: 'comment_filter', name: 'Comment Filter', desc: 'Hides spam or toxic comments automatically.', icon: '' },
                                { id: 'fast_playback', name: 'Fast Playback', desc: 'Adds support for up to 16x playback speed.', icon: '' }
                            ];

                            const renderExtensions = () => {
                                browseArea.textContent = '';
                                installedArea.textContent = '';
                                
                                let installedCount = 0;

                                availableExtensions.forEach(ext => {
                                    const isInstalled = window.gestubeExtensions[ext.id];
                                    
                                    const card = document.createElement('div');
                                    card.style.cssText = 'background: rgba(255,255,255,0.05); padding: 15px; border-radius: 8px; border: 1px solid ' + (isInstalled ? 'rgba(106, 13, 173, 0.5)' : 'rgba(255,255,255,0.1)') + '; display: flex; align-items: center; justify-content: space-between;';
                                    
                                    const info = document.createElement('div');
                                    
                                    const infoTitle = document.createElement('div');
                                    infoTitle.textContent = ext.icon + ' ' + ext.name;
                                    infoTitle.style.cssText = 'font-size:16px; font-weight:bold; margin-bottom:5px;';
                                    
                                    const infoDesc = document.createElement('div');
                                    infoDesc.textContent = ext.desc;
                                    infoDesc.style.cssText = 'font-size:12px; color:#aaa;';
                                    
                                    info.appendChild(infoTitle);
                                    info.appendChild(infoDesc);
                                    
                                    const actionBtn = document.createElement('button');
                                    actionBtn.textContent = isInstalled ? 'Uninstall' : 'Install';
                                    actionBtn.style.cssText = 'padding: 8px 15px; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; ' + (isInstalled ? 'background: #ff4444; color: white;' : 'background: #6a0dad; color: white;');
                                    
                                    actionBtn.onclick = () => {
                                        window.gestubeExtensions[ext.id] = !isInstalled;
                                        localStorage.setItem('gestube_extensions_state', JSON.stringify(window.gestubeExtensions));
                                        renderExtensions();
                                        if (!window.gestubeExtensions[ext.id] && ext.id === 'vidiq') {
                                            const p = document.getElementById('gestube-vidiq-panel');
                                            if (p) p.remove();
                                        }
                                    };
                                    
                                    card.appendChild(info);
                                    card.appendChild(actionBtn);
                                    
                                    if (isInstalled) {
                                        installedArea.appendChild(card);
                                        installedCount++;
                                    } else {
                                        browseArea.appendChild(card);
                                    }
                                });
                                
                                if (installedCount === 0) {
                                    const noExt = document.createElement('div');
                                    noExt.textContent = 'No extensions installed.';
                                    noExt.style.cssText = 'color:#aaa; text-align:center; padding:20px;';
                                    installedArea.appendChild(noExt);
                                }
                            };
                            
                            renderExtensions();
                            modalContent.appendChild(extView);

                            extensionsBtn.onclick = () => {
                                homeView.style.display = 'none';
                                extView.style.display = 'flex';
                                renderExtensions();
                            };

                            // --- View 2: Settings View ---
                            const settingsView = document.createElement('div');
                            settingsView.id = 'gestube-settings-view';
                            settingsView.style.display = 'none';

                            const backBtn = document.createElement('button');
                            backBtn.className = 'gestube-btn';
                            backBtn.textContent = '< Back';
                            backBtn.style.cssText = 'margin-bottom: 20px; font-size: 14px;';
                            settingsView.appendChild(backBtn);
                            
                            const settingsTitle = document.createElement('div');
                            settingsTitle.textContent = 'Settings';
                            settingsTitle.style.cssText = 'font-size: 24px; font-weight: bold; margin-bottom: 20px;';
                            settingsView.appendChild(settingsTitle);

                            // Tabs Container
                            const tabsContainer = document.createElement('div');
                            tabsContainer.style.cssText = 'display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.1);';
                            
                            const shortsTabBtn = document.createElement('button');
                            shortsTabBtn.textContent = 'Shorts';
                            shortsTabBtn.className = 'gestube-tab-btn active';
                            
                            const longTabBtn = document.createElement('button');
                            longTabBtn.textContent = 'Long Videos';
                            longTabBtn.className = 'gestube-tab-btn';

                            tabsContainer.appendChild(shortsTabBtn);
                            tabsContainer.appendChild(longTabBtn);
                            settingsView.appendChild(tabsContainer);

                            // Shorts Section (Inside Settings)
                            const shortsSettingsSec = document.createElement('div');
                            shortsSettingsSec.style.cssText = 'display: block;';
                            
                            const optimizerTitle = document.createElement('div');
                            optimizerTitle.textContent = 'Feed Optimizer (Skip Niches)';
                            optimizerTitle.style.cssText = 'font-size: 14px; font-weight: bold; color: #aaa; margin-bottom: 10px; margin-left: 10px;';
                            shortsSettingsSec.appendChild(optimizerTitle);

                            const createAccordion = (nicheId, nicheLabel, subNiches) => {
                                const accContainer = document.createElement('div');
                                accContainer.style.cssText = 'margin-bottom: 10px; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 10px;';
                                
                                const header = document.createElement('div');
                                header.style.cssText = 'display: flex; align-items: center; justify-content: space-between; cursor: pointer;';
                                
                                const checkWrap = document.createElement('div');
                                checkWrap.style.cssText = 'display: flex; align-items: center; gap: 10px;';
                                
                                const masterCheck = document.createElement('input');
                                masterCheck.type = 'checkbox';
                                masterCheck.id = 'gestube-niche-' + nicheId;
                                masterCheck.style.cssText = 'width: 18px; height: 18px; cursor: pointer;';
                                
                                const label = document.createElement('label');
                                label.htmlFor = masterCheck.id;
                                label.textContent = nicheLabel;
                                label.style.cssText = 'cursor: pointer; font-size: 16px; user-select: none;';
                                
                                checkWrap.appendChild(masterCheck);
                                checkWrap.appendChild(label);
                                
                                const toggleBtn = document.createElement('button');
                                toggleBtn.textContent = 'v';
                                toggleBtn.style.cssText = 'background: none; border: none; color: #fff; cursor: pointer; font-size: 12px; padding: 10px; flex-grow: 1; text-align: right; margin-left: 20px; outline: none; height: 100%;';
                                
                                header.appendChild(checkWrap);
                                header.appendChild(toggleBtn);
                                
                                const subContainer = document.createElement('div');
                                subContainer.style.cssText = 'display: none; padding-left: 28px; margin-top: 10px; gap: 8px; flex-direction: column;';
                                
                                const subChecks = [];
                                
                                subNiches.forEach(sub => {
                                    const subWrap = document.createElement('div');
                                    subWrap.style.cssText = 'display: flex; align-items: center; gap: 8px;';
                                    
                                    const subCheck = document.createElement('input');
                                    subCheck.type = 'checkbox';
                                    subCheck.id = 'gestube-sub-' + nicheId + '-' + sub.id;
                                    subCheck.style.cssText = 'width: 16px; height: 16px; cursor: pointer;';
                                    
                                    const subLabel = document.createElement('label');
                                    subLabel.htmlFor = subCheck.id;
                                    subLabel.textContent = sub.label;
                                    subLabel.style.cssText = 'cursor: pointer; font-size: 14px; color: #ccc; user-select: none;';
                                    
                                    subWrap.appendChild(subCheck);
                                    subWrap.appendChild(subLabel);
                                    subContainer.appendChild(subWrap);
                                    
                                    subChecks.push({ check: subCheck, id: sub.id });
                                });
                                
                                accContainer.appendChild(header);
                                accContainer.appendChild(subContainer);
                                
                                // Toggle logic
                                toggleBtn.onclick = (e) => {
                                    e.stopPropagation();
                                    const isHidden = subContainer.style.display === 'none';
                                    subContainer.style.display = isHidden ? 'flex' : 'none';
                                    toggleBtn.textContent = isHidden ? 'v' : '^';
                                };
                                
                                return { element: accContainer, masterCheck, subChecks };
                            };

                            const optimizerContainer = document.createElement('div');
                            optimizerContainer.style.cssText = 'background: rgba(255,255,255,0.05); padding: 15px; border-radius: 8px;';
                            
                            const gamingAcc = createAccordion('gaming', ' Gaming', [
                                { id: 'minecraft', label: 'Minecraft tips and ticks' }, { id: 'roblox', label: 'Roblox rants' }, 
                                { id: 'gta', label: 'GTA' }, { id: 'fortnite', label: 'Fortnite' }, 
                                { id: 'valorant', label: 'Valorant' }, { id: 'cod', label: 'Call of Duty' },
                                { id: 'freefire', label: 'Free Fire' }
                            ]);
                            const musicAcc = createAccordion('music', ' Music', [
                                { id: 'pop', label: 'Pop' }, { id: 'rap', label: 'Rap' }, 
                                { id: 'remix', label: 'Remix' }, { id: 'concert', label: 'Concert' }, 
                                { id: 'cover', label: 'Cover' }, { id: 'phonk', label: 'Phonk' }
                            ]);
                            const newsAcc = createAccordion('news', ' News', [
                                { id: 'politics', label: 'Politics' }, { id: 'podcast', label: 'Podcast' }, 
                                { id: 'daily', label: 'Daily News' }
                            ]);
                            const sportsAcc = createAccordion('sports', ' Sports', [
                                { id: 'nba', label: 'NBA' }, { id: 'nfl', label: 'NFL' }, 
                                { id: 'soccer', label: 'Soccer' }
                            ]);
                            const cringeAcc = createAccordion('cringe', ' Cringe', [
                                { id: 'sound', label: 'Use this sound' }, { id: 'sub', label: 'Subscribe' }, 
                                { id: 'viral', label: 'Viral / Algorithm' }, { id: 'stupid', label: 'Stupid' }
                            ]);
                            const editsAcc = createAccordion('edits', ' Edits', [
                                { id: 'football', label: 'football edit' }, { id: 'nfl_edit', label: 'NFL edits' },
                                { id: 'random', label: 'Random Edits' }, { id: 'roblox_edit', label: 'Roblox edits' },
                                { id: 'minecraft_edit', label: 'Minecraft edits' }, { id: 'newvsold', label: 'New VS Old edits' },
                                { id: 'freefire_edit', label: 'FreeFire Edits' }
                            ]);
                            const memesAcc = createAccordion('memes', ' Memes', [
                                { id: 'reaction', label: 'Reaction memes' }, { id: 'photo', label: '2 photo memes' }
                            ]);
                            
                            optimizerContainer.appendChild(gamingAcc.element);
                            optimizerContainer.appendChild(musicAcc.element);
                            optimizerContainer.appendChild(newsAcc.element);
                            optimizerContainer.appendChild(sportsAcc.element);
                            optimizerContainer.appendChild(cringeAcc.element);
                            optimizerContainer.appendChild(editsAcc.element);
                            optimizerContainer.appendChild(memesAcc.element);
                            
                            window.gestubeAccordions = { gaming: gamingAcc, music: musicAcc, news: newsAcc, sports: sportsAcc, cringe: cringeAcc, edits: editsAcc, memes: memesAcc };
                            
                            const visualBtn = document.createElement('button');
                            visualBtn.className = 'gestube-btn';
                            visualBtn.textContent = 'Visual Feed Optimizer';
                            visualBtn.style.cssText = 'width: 100%; margin-top: 15px; background: rgba(0, 120, 215, 0.5); font-size: 13px;';
                            visualBtn.onclick = () => {
                                // Hide the settings modal
                                const homeModal = document.getElementById('gestube-home-modal');
                                if (homeModal) homeModal.style.display = 'none';
                                
                                const overlay = document.createElement('div');
                                overlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.8); z-index: 99999; display: flex; justify-content: center; align-items: center; backdrop-filter: blur(5px);';
                                
                                const modal = document.createElement('div');
                                modal.style.cssText = 'background: #181818; border-radius: 16px; padding: 30px; width: 450px; max-width: 90%; color: #fff; font-family: Roboto, sans-serif; box-shadow: 0 10px 30px rgba(0,0,0,0.8); text-align: center; border: 1px solid rgba(255,255,255,0.1);';
                                
                                const title = document.createElement('h2');
                                title.textContent = 'Disclaimer';
                                title.style.cssText = 'margin: 0 0 15px 0; font-size: 22px; font-weight: 600; color: #fff;';
                                
                                const text = document.createElement('p');
                                text.textContent = 'The YouTube Shorts shown in this setup process are randomly selected examples used strictly to customize your feed algorithm. We do not own these videos. Do you wish to continue?';
                                text.style.cssText = 'margin: 0 0 30px 0; font-size: 15px; line-height: 1.5; color: #aaa;';
                                
                                const btnContainer = document.createElement('div');
                                btnContainer.style.cssText = 'display: flex; gap: 15px; justify-content: center;';
                                
                                const cancelBtn = document.createElement('button');
                                cancelBtn.textContent = 'Cancel';
                                cancelBtn.style.cssText = 'padding: 12px 24px; border: none; border-radius: 20px; background: rgba(255,255,255,0.1); color: #fff; cursor: pointer; font-weight: 600; font-size: 14px; flex: 1; transition: background 0.2s;';
                                cancelBtn.onmouseover = () => cancelBtn.style.background = 'rgba(255,255,255,0.2)';
                                cancelBtn.onmouseout = () => cancelBtn.style.background = 'rgba(255,255,255,0.1)';
                                cancelBtn.onclick = () => document.body.removeChild(overlay);
                                
                                const continueBtn = document.createElement('button');
                                continueBtn.textContent = 'Continue';
                                continueBtn.style.cssText = 'padding: 12px 24px; border: none; border-radius: 20px; background: #3ea6ff; color: #000; cursor: pointer; font-weight: 600; font-size: 14px; flex: 1; transition: background 0.2s;';
                                continueBtn.onmouseover = () => continueBtn.style.background = '#65b8ff';
                                continueBtn.onmouseout = () => continueBtn.style.background = '#3ea6ff';
                                continueBtn.onclick = () => {
                                    document.body.removeChild(overlay);
                                    sessionStorage.setItem('gestube_onboarding_step', '0');
                                    window.location.href = '/shorts/AHeFrQNY8s4'; // Start with Minecraft tips
                                };
                                
                                btnContainer.appendChild(cancelBtn);
                                btnContainer.appendChild(continueBtn);
                                
                                modal.appendChild(title);
                                modal.appendChild(text);
                                modal.appendChild(btnContainer);
                                overlay.appendChild(modal);
                                
                                document.body.appendChild(overlay);
                            };
                            
                            sidebarContent.appendChild(shortsSec);
                            
                            shortsSettingsSec.appendChild(optimizerContainer);
                            shortsSettingsSec.appendChild(visualBtn);
                            
                            settingsView.appendChild(shortsSettingsSec);

                            // Long Videos Section (Inside Settings)
                            const longSettingsSec = document.createElement('div');
                            longSettingsSec.style.cssText = 'display: none;';
                            
                            const longSettingsContent = document.createElement('div');
                            longSettingsContent.style.cssText = 'display: flex; flex-direction: column; gap: 12px;';
                            
                            const createToggle = (id, labelText, settingKey) => {
                                const wrap = document.createElement('div');
                                wrap.style.cssText = 'display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.05); padding: 12px 15px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1);';
                                const label = document.createElement('label');
                                label.htmlFor = id;
                                label.textContent = labelText;
                                label.style.cssText = 'font-size: 15px; cursor: pointer; user-select: none; flex-grow: 1;';
                                const check = document.createElement('input');
                                check.type = 'checkbox';
                                check.id = id;
                                check.checked = window.gestubeLongSettings[settingKey];
                                check.style.cssText = 'width: 18px; height: 18px; cursor: pointer; accent-color: #ff007f;';
                                check.addEventListener('change', (e) => {
                                    window.gestubeLongSettings[settingKey] = e.target.checked;
                                    localStorage.setItem('gestube_long_settings', JSON.stringify(window.gestubeLongSettings));
                                });
                                wrap.appendChild(label);
                                wrap.appendChild(check);
                                return wrap;
                            };

                            const createSelect = (id, labelText, settingKey, options) => {
                                const wrap = document.createElement('div');
                                wrap.style.cssText = 'display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.05); padding: 12px 15px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1);';
                                const label = document.createElement('label');
                                label.htmlFor = id;
                                label.textContent = labelText;
                                label.style.cssText = 'font-size: 15px; cursor: pointer; user-select: none;';
                                const select = document.createElement('select');
                                select.id = id;
                                select.style.cssText = 'background: #222; color: #fff; border: 1px solid #444; padding: 5px 10px; border-radius: 4px; outline: none; cursor: pointer; font-size: 14px;';
                                options.forEach(opt => {
                                    const o = document.createElement('option');
                                    o.value = opt.value;
                                    o.textContent = opt.label;
                                    select.appendChild(o);
                                });
                                select.value = window.gestubeLongSettings[settingKey];
                                select.addEventListener('change', (e) => {
                                    window.gestubeLongSettings[settingKey] = e.target.value;
                                    localStorage.setItem('gestube_long_settings', JSON.stringify(window.gestubeLongSettings));
                                });
                                wrap.appendChild(label);
                                wrap.appendChild(select);
                                return wrap;
                            };

                            longSettingsContent.appendChild(createToggle('gls-sponsor', ' Auto-Skip Sponsors', 'sponsorBlock'));
                            longSettingsContent.appendChild(createToggle('gls-focus', ' Focus Mode (Theater)', 'focusMode'));
                            longSettingsContent.appendChild(createToggle('gls-vol', ' 200% Volume Booster', 'volumeBoost'));
                            longSettingsContent.appendChild(createToggle('gls-resume', ' Auto-Resume Videos', 'autoResume'));
                            
                            longSettingsContent.appendChild(createSelect('gls-quality', ' Default Video Quality', 'quality', [
                                {value: 'auto', label: 'Auto'},
                                {value: 'hd1080', label: '1080p'},
                                {value: 'hd2160', label: '4K'},
                                {value: 'hd720', label: '720p'}
                            ]));

                            longSettingsContent.appendChild(createSelect('gls-speed', ' Default Playback Speed', 'speed', [
                                {value: '1.0', label: '1.0x (Normal)'},
                                {value: '1.25', label: '1.25x'},
                                {value: '1.5', label: '1.5x'},
                                {value: '2.0', label: '2.0x'}
                            ]));

                            const declutterWrap = document.createElement('div');
                            declutterWrap.style.cssText = 'background: rgba(255,255,255,0.05); padding: 12px 15px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1); display: flex; flex-direction: column; gap: 10px;';
                            const decLabel = document.createElement('div');
                            decLabel.textContent = ' Declutter Elements';
                            decLabel.style.cssText = 'font-weight: bold; font-size: 15px; margin-bottom: 5px;';
                            declutterWrap.appendChild(decLabel);

                            ['hideComments', 'hideSidebar', 'hideChat'].forEach(key => {
                                const l = key.replace('hide', '');
                                const w = document.createElement('div');
                                w.style.cssText = 'display: flex; align-items: center; gap: 10px;';
                                const c = document.createElement('input');
                                c.type = 'checkbox';
                                c.checked = window.gestubeLongSettings[key];
                                c.style.cssText = 'cursor: pointer; accent-color: #ff007f; width: 16px; height: 16px;';
                                c.addEventListener('change', (e) => {
                                    window.gestubeLongSettings[key] = e.target.checked;
                                    localStorage.setItem('gestube_long_settings', JSON.stringify(window.gestubeLongSettings));
                                });
                                const lbl = document.createElement('label');
                                lbl.textContent = 'Hide ' + l;
                                lbl.style.cursor = 'pointer';
                                lbl.onclick = () => c.click();
                                w.appendChild(c);
                                w.appendChild(lbl);
                                declutterWrap.appendChild(w);
                            });
                            longSettingsContent.appendChild(declutterWrap);
                            
                            longSettingsSec.appendChild(longSettingsContent);
                            settingsView.appendChild(longSettingsSec);

                            modalContent.appendChild(settingsView);
                            document.body.appendChild(modal);

                            // Tab Switching Logic
                            shortsTabBtn.onclick = () => {
                                shortsTabBtn.classList.add('active');
                                longTabBtn.classList.remove('active');
                                shortsSettingsSec.style.display = 'block';
                                longSettingsSec.style.display = 'none';
                            };
                            
                            longTabBtn.onclick = () => {
                                longTabBtn.classList.add('active');
                                shortsTabBtn.classList.remove('active');
                                longSettingsSec.style.display = 'block';
                                shortsSettingsSec.style.display = 'none';
                            };

                            // Navigation Logic
                            settingsBtn.onclick = () => {
                                homeView.style.display = 'none';
                                settingsView.style.display = 'block';
                                headerTitle.textContent = 'Settings';
                            };
                            backBtn.onclick = () => {
                                settingsView.style.display = 'none';
                                homeView.style.display = 'block';
                                headerTitle.textContent = 'Home Screen';
                            };

                            // Drag Logic
                            let isDragging = false;
                            let initialX;
                            let initialY;

                            modalHeader.addEventListener('mousedown', (e) => {
                                const rect = modal.getBoundingClientRect();
                                initialX = e.clientX - rect.left;
                                initialY = e.clientY - rect.top;
                                isDragging = true;
                            });

                            // Resizing Logic
                            const handles = ['n', 'e', 's', 'w', 'ne', 'nw', 'se', 'sw'];
                            let activeHandle = null;
                            let startWidth, startHeight, startLeft, startTop, startMouseX, startMouseY;

                            handles.forEach(dir => {
                                const handle = document.createElement('div');
                                handle.style.position = 'absolute';
                                handle.style.zIndex = '9999999';
                                if (dir === 'n') { handle.style.top = '-5px'; handle.style.left = '0'; handle.style.width = '100%'; handle.style.height = '10px'; handle.style.cursor = 'ns-resize'; }
                                if (dir === 's') { handle.style.bottom = '-5px'; handle.style.left = '0'; handle.style.width = '100%'; handle.style.height = '10px'; handle.style.cursor = 'ns-resize'; }
                                if (dir === 'e') { handle.style.top = '0'; handle.style.right = '-5px'; handle.style.width = '10px'; handle.style.height = '100%'; handle.style.cursor = 'ew-resize'; }
                                if (dir === 'w') { handle.style.top = '0'; handle.style.left = '-5px'; handle.style.width = '10px'; handle.style.height = '100%'; handle.style.cursor = 'ew-resize'; }
                                if (dir === 'ne') { handle.style.top = '-5px'; handle.style.right = '-5px'; handle.style.width = '15px'; handle.style.height = '15px'; handle.style.cursor = 'nesw-resize'; }
                                if (dir === 'nw') { handle.style.top = '-5px'; handle.style.left = '-5px'; handle.style.width = '15px'; handle.style.height = '15px'; handle.style.cursor = 'nwse-resize'; }
                                if (dir === 'se') { handle.style.bottom = '-5px'; handle.style.right = '-5px'; handle.style.width = '15px'; handle.style.height = '15px'; handle.style.cursor = 'nwse-resize'; }
                                if (dir === 'sw') { handle.style.bottom = '-5px'; handle.style.left = '-5px'; handle.style.width = '15px'; handle.style.height = '15px'; handle.style.cursor = 'nesw-resize'; }
                                
                                handle.addEventListener('mousedown', (e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    activeHandle = dir;
                                    const rect = modal.getBoundingClientRect();
                                    startWidth = rect.width;
                                    startHeight = rect.height;
                                    startLeft = rect.left;
                                    startTop = rect.top;
                                    startMouseX = e.clientX;
                                    startMouseY = e.clientY;
                                });
                                modal.appendChild(handle);
                            });

                            window.addEventListener('mouseup', () => {
                                isDragging = false;
                                activeHandle = null;
                            });

                            window.addEventListener('mousemove', (e) => {
                                if (activeHandle) {
                                    e.preventDefault();
                                    const dx = e.clientX - startMouseX;
                                    const dy = e.clientY - startMouseY;
                                    let newWidth = startWidth, newHeight = startHeight, newLeft = startLeft, newTop = startTop;
                                    
                                    if (activeHandle.includes('e')) newWidth = startWidth + dx;
                                    if (activeHandle.includes('s')) newHeight = startHeight + dy;
                                    if (activeHandle.includes('w')) { newWidth = startWidth - dx; newLeft = startLeft + dx; }
                                    if (activeHandle.includes('n')) { newHeight = startHeight - dy; newTop = startTop + dy; }
                                    
                                    if (newWidth > 400) { modal.style.width = newWidth + 'px'; modal.style.left = newLeft + 'px'; }
                                    if (newHeight > 300) { modal.style.height = newHeight + 'px'; modal.style.top = newTop + 'px'; }
                                } else if (isDragging) {
                                    e.preventDefault();
                                    let currentX = e.clientX - initialX;
                                    let currentY = e.clientY - initialY;
                                    
                                    // Make sure it doesn't drag completely off screen
                                    if (currentX < 0) currentX = 0;
                                    if (currentY < 0) currentY = 0;
                                    if (currentX > window.innerWidth - 100) currentX = window.innerWidth - 100;
                                    if (currentY > window.innerHeight - 50) currentY = window.innerHeight - 50;
                                    
                                    modal.style.left = currentX + 'px';
                                    modal.style.top = currentY + 'px';
                                }
                            });

                            // --- View 5: Bins View ---
                            const binsView = document.createElement('div');
                            binsView.id = 'gestube-bins-view';
                            binsView.style.cssText = 'display: none; flex-direction: column; flex: 1;';
                            
                            const binsBackBtn = document.createElement('button');
                            binsBackBtn.className = 'gestube-btn';
                            binsBackBtn.textContent = '< Back';
                            binsBackBtn.style.cssText = 'margin-bottom: 20px; font-size: 14px; align-self: flex-start;';
                            binsBackBtn.onclick = () => {
                                binsView.style.display = 'none';
                                homeView.style.display = 'block';
                            };
                            binsView.appendChild(binsBackBtn);

                            const binsTitle = document.createElement('div');
                            binsTitle.textContent = ' Dust Bins';
                            binsTitle.style.cssText = 'font-size: 24px; font-weight: bold; margin-bottom: 15px; color: #ff4c4c;';
                            binsView.appendChild(binsTitle);

                            const binsTabs = document.createElement('div');
                            binsTabs.style.cssText = 'display: flex; gap: 10px; margin-bottom: 20px;';
                            const channelsTabBtn = document.createElement('button');
                            channelsTabBtn.textContent = 'Channels';
                            channelsTabBtn.style.cssText = 'flex: 1; padding: 10px; border: none; border-radius: 8px; background: #8B0000; color: white; cursor: pointer; font-weight: bold;';
                            const soundsTabBtn = document.createElement('button');
                            soundsTabBtn.textContent = 'Sounds';
                            soundsTabBtn.style.cssText = 'flex: 1; padding: 10px; border: none; border-radius: 8px; background: #282828; color: white; cursor: pointer; font-weight: bold;';
                            binsTabs.appendChild(channelsTabBtn);
                            binsTabs.appendChild(soundsTabBtn);
                            binsView.appendChild(binsTabs);

                            const channelsArea = document.createElement('div');
                            channelsArea.style.cssText = 'display: flex; flex-direction: column; gap: 10px; flex: 1; overflow-y: auto;';
                            const soundsArea = document.createElement('div');
                            soundsArea.style.cssText = 'display: none; flex-direction: column; gap: 10px; flex: 1; overflow-y: auto;';
                            binsView.appendChild(channelsArea);
                            binsView.appendChild(soundsArea);

                            channelsTabBtn.onclick = () => {
                                channelsTabBtn.style.background = '#8B0000';
                                soundsTabBtn.style.background = '#282828';
                                channelsArea.style.display = 'flex';
                                soundsArea.style.display = 'none';
                            };
                            soundsTabBtn.onclick = () => {
                                soundsTabBtn.style.background = '#8B0000';
                                channelsTabBtn.style.background = '#282828';
                                soundsArea.style.display = 'flex';
                                channelsArea.style.display = 'none';
                            };

                            const renderBins = () => {
                                channelsArea.innerHTML = '';
                                soundsArea.innerHTML = '';
                                
                                if (!window.gestubeIgnoredChannels || window.gestubeIgnoredChannels.length === 0) {
                                    channelsArea.innerHTML = '<div style=""color:#aaa; text-align:center; padding:20px;"">No dusted channels.</div>';
                                } else {
                                    window.gestubeIgnoredChannels.forEach((ch, idx) => {
                                        const item = document.createElement('div');
                                        item.style.cssText = 'background: rgba(255,255,255,0.05); padding: 10px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;';
                                        const text = document.createElement('div');
                                        text.textContent = ch;
                                        const unBtn = document.createElement('button');
                                        unBtn.textContent = 'Un-dust';
                                        unBtn.style.cssText = 'background: #4CAF50; color: white; border: none; border-radius: 4px; padding: 5px 10px; cursor: pointer; font-weight: bold;';
                                        unBtn.onclick = () => {
                                            window.gestubeIgnoredChannels.splice(idx, 1);
                                            localStorage.setItem('gestube_ignored_channels', JSON.stringify(window.gestubeIgnoredChannels));
                                            renderBins();
                                        };
                                        item.appendChild(text);
                                        item.appendChild(unBtn);
                                        channelsArea.appendChild(item);
                                    });
                                }

                                if (!window.gestubeIgnoredSounds || window.gestubeIgnoredSounds.length === 0) {
                                    soundsArea.innerHTML = '<div style=""color:#aaa; text-align:center; padding:20px;"">No dusted sounds.</div>';
                                } else {
                                    window.gestubeIgnoredSounds.forEach((snd, idx) => {
                                        const item = document.createElement('div');
                                        item.style.cssText = 'background: rgba(255,255,255,0.05); padding: 10px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;';
                                        const text = document.createElement('div');
                                        text.textContent = snd;
                                        const unBtn = document.createElement('button');
                                        unBtn.textContent = 'Un-dust';
                                        unBtn.style.cssText = 'background: #4CAF50; color: white; border: none; border-radius: 4px; padding: 5px 10px; cursor: pointer; font-weight: bold;';
                                        unBtn.onclick = () => {
                                            window.gestubeIgnoredSounds.splice(idx, 1);
                                            localStorage.setItem('gestube_ignored_sounds', JSON.stringify(window.gestubeIgnoredSounds));
                                            renderBins();
                                        };
                                        item.appendChild(text);
                                        item.appendChild(unBtn);
                                        soundsArea.appendChild(item);
                                    });
                                }
                            };
                            
                            binsBtn.onclick = () => {
                                homeView.style.display = 'none';
                                binsView.style.display = 'flex';
                                renderBins();
                            };

                            modalContent.appendChild(binsView);

                            let gestubeAudioCtx = null;
                            let gestubeGainNode = null;

                            // Modal Toggle Logic
                            document.addEventListener('play', (e) => {
                                if (e.target && e.target.tagName === 'VIDEO') {
                                    const m = document.getElementById('gestube-home-modal');
                                    if (m && (m.style.display === 'flex' || m.style.display === 'block') && !m.contains(e.target)) {
                                        e.target.pause();
                                        return;
                                    }

                                    const isWatch = window.location.pathname.startsWith('/watch');
                                    if (isWatch) {
                                        const s = window.gestubeLongSettings;
                                        
                                        // Speed
                                        if (s.speed && s.speed !== '1.0') {
                                            e.target.playbackRate = parseFloat(s.speed);
                                        }

                                        // Quality
                                        if (s.quality && s.quality !== 'auto') {
                                            const player = document.getElementById('movie_player');
                                            if (player && typeof player.setPlaybackQualityRange === 'function') {
                                                player.setPlaybackQualityRange(s.quality);
                                            }
                                        }

                                        // Auto-Resume
                                        if (s.autoResume && e.target.currentTime < 2) {
                                            const videoId = new URLSearchParams(window.location.search).get('v');
                                            if (videoId) {
                                                const savedTime = localStorage.getItem('gestube_resume_' + videoId);
                                                if (savedTime && parseFloat(savedTime) > 5) {
                                                    e.target.currentTime = parseFloat(savedTime);
                                                }
                                            }
                                        }

                                        // Volume Booster
                                        try {
                                            // Disabled Web Audio API due to YouTube dynamic <video> swapping stalling playback
                                            /*
                                            if (!gestubeAudioCtx && s.volumeBoost) {
                                                gestubeAudioCtx = new (window.AudioContext || window.webkitAudioContext)();
                                                gestubeGainNode = gestubeAudioCtx.createGain();
                                                const source = gestubeAudioCtx.createMediaElementSource(e.target);
                                                source.connect(gestubeGainNode);
                                                gestubeGainNode.connect(gestubeAudioCtx.destination);
                                            }
                                            if (gestubeGainNode) {
                                                gestubeGainNode.gain.value = s.volumeBoost ? 2.5 : 1.0;
                                                if (gestubeAudioCtx.state === 'suspended') gestubeAudioCtx.resume();
                                            }
                                            */
                                        } catch(err) { console.error('Audio Boost Error', err); }
                                    }
                                }
                            }, true);

                            const openHomeModal = () => {
                                modal.style.display = 'flex';
                                document.body.style.overflow = 'hidden'; // Prevent bg scrolling
                                const vids = document.getElementsByTagName('video');
                                for(let i=0; i<vids.length; i++) { if (!vids[i].paused) vids[i].pause(); }
                                
                                // Forcefully reset the views to always show the Home Screen
                                const hv = document.getElementById('gestube-home-view');
                                const sv = document.getElementById('gestube-settings-view');
                                const dv = document.getElementById('gestube-downloads-view');
                                const bv = document.getElementById('gestube-bins-view');
                                if (hv) hv.style.display = 'block';
                                if (sv) sv.style.display = 'none';
                                if (dv) dv.style.display = 'none';
                                if (bv) bv.style.display = 'none';

                                // Center it on first open
                                if (!modal.dataset.positioned) {
                                    modal.style.top = Math.max(0, (window.innerHeight - 500) / 2) + 'px';
                                    modal.style.left = Math.max(0, (window.innerWidth - 600) / 2) + 'px';
                                    modal.dataset.positioned = 'true';
                                }
                            };
                            
                            title.style.cursor = 'pointer';
                            title.onclick = openHomeModal;
                            homeBtn.onclick = openHomeModal;
                            
                            closeBtn.onclick = () => {
                                modal.style.display = 'none';
                                document.body.style.overflow = ''; // Restore bg scrolling
                            };

                            // Attach Event Listeners
                            setTimeout(() => {
                                document.getElementById('gestube-skip-ads').addEventListener('change', (e) => window.skipAdsEnabled = e.target.checked);
                                document.getElementById('gestube-scroll-shorts').addEventListener('change', (e) => window.autoScrollShortsEnabled = e.target.checked);
                                document.getElementById('gestube-skip-short-ads').addEventListener('change', (e) => window.autoSkipShortAdsEnabled = e.target.checked);
                                
                                // Bind Accordion State to window.gestubeNiches
                                Object.keys(window.gestubeAccordions).forEach(nicheKey => {
                                    const acc = window.gestubeAccordions[nicheKey];
                                    
                                    // Set initial checked state from window.gestubeNiches
                                    acc.masterCheck.checked = window.gestubeNiches[nicheKey]._all;
                                    acc.subChecks.forEach(sub => {
                                        sub.check.checked = window.gestubeNiches[nicheKey][sub.id];
                                    });
                                    
                                    // Master Checkbox Logic
                                    acc.masterCheck.addEventListener('change', (e) => {
                                        const isChecked = e.target.checked;
                                        window.gestubeNiches[nicheKey]._all = isChecked;
                                        acc.subChecks.forEach(sub => {
                                            sub.check.checked = isChecked;
                                            window.gestubeNiches[nicheKey][sub.id] = isChecked;
                                        });
                                        localStorage.setItem('gestube_niches_state', JSON.stringify(window.gestubeNiches));
                                    });
                                    
                                    // Sub Checkbox Logic
                                    acc.subChecks.forEach(sub => {
                                        sub.check.addEventListener('change', (e) => {
                                            window.gestubeNiches[nicheKey][sub.id] = e.target.checked;
                                            
                                            // If all subs are checked, check master. If not, uncheck master.
                                            const allChecked = acc.subChecks.every(s => s.check.checked);
                                            acc.masterCheck.checked = allChecked;
                                            window.gestubeNiches[nicheKey]._all = allChecked;
                                            localStorage.setItem('gestube_niches_state', JSON.stringify(window.gestubeNiches));
                                        });
                                    });
                                });
                            }, 100);

                            // YouTube dynamically clears the DOM when you click a video (SPA navigation).
                            // This MutationObserver ensures the sidebar and styles are instantly put back if YouTube deletes them.
                            const observer = new MutationObserver(() => {
                                if (!document.getElementById('gestube-sidebar') && document.body) document.body.appendChild(sidebar);
                                if (!document.getElementById('gestube-hover-area') && document.body && typeof hoverArea !== 'undefined') document.body.appendChild(hoverArea);
                                if (!document.getElementById('gestube-home-modal') && document.body) document.body.appendChild(modal);
                                if (!document.getElementById('gestube-style') && document.head) document.head.appendChild(style);
                                // Removed global dust button observer
                            });
                            observer.observe(document.documentElement, { childList: true, subtree: true });

                            // 3. Mobile Drawer & Touch Logic
                            let backdrop = document.getElementById('gestube-sidebar-backdrop');
                            if (!backdrop) {
                                backdrop = document.createElement('div');
                                backdrop.id = 'gestube-sidebar-backdrop';
                                backdrop.style.cssText = 'position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.65); z-index: 9999998; display: none;';
                                document.body.appendChild(backdrop);
                            }

                            const collapseSidebar = (e) => {
                                if (e) e.stopPropagation();
                                sidebar.classList.add('collapsed');
                                panel.style.display = 'none';
                                if (backdrop) backdrop.style.display = 'none';
                            };

                            const expandSidebar = (e) => {
                                if (e) e.stopPropagation();
                                sidebar.classList.remove('collapsed');
                                panel.style.display = 'flex';
                                if (backdrop) backdrop.style.display = 'block';
                            };

                            const toggleSidebar = (e) => {
                                if (e) {
                                    e.stopPropagation();
                                    if (e.cancelable) e.preventDefault();
                                }
                                if (sidebar.classList.contains('collapsed') || panel.style.display === 'none') {
                                    expandSidebar(e);
                                } else {
                                    collapseSidebar(e);
                                }
                            };

                            handle.onclick = toggleSidebar;
                            backdrop.onclick = collapseSidebar;
                            backdrop.ontouchend = collapseSidebar;

                            collapseSidebar();

                            // 4. Ad Blocker Logic
                            // Aggressively hide ad elements via CSS
                            const adStyle = document.createElement('style');
                            adStyle.id = 'gestube-adstyle';
                            adStyle.textContent = `
                                .ad-showing .ytp-ad-module,
                                .ytp-ad-player-overlay,
                                .ytp-ad-preview-container,
                                .ytp-ad-image-overlay,
                                .ytp-ad-skip-ad-slot,
                                ytd-promoted-sparkles-web-renderer,
                                ytd-display-ad-renderer,
                                ytd-action-companion-ad-renderer {
                                    display: none !important;
                                    opacity: 0 !important;
                                    visibility: hidden !important;
                                }
                            `;
                            document.head.appendChild(adStyle);

                            let lastGestubeLongSettingsStr = '';
                            let lastPathnameForLongSettings = '';
                            const applyLongSettings = () => {
                                let css = '';
                                const isWatch = window.location.pathname.startsWith('/watch');
                                if (isWatch) {
                                    const s = window.gestubeLongSettings;
                                    if (s.hideComments) css += '#comments { display: none !important; }\n';
                                    if (s.hideSidebar) css += '#secondary { display: none !important; }\n';
                                    if (s.hideChat) css += '#chat { display: none !important; }\n';
                                    
                                    if (s.focusMode) {
                                        css += `
                                            #secondary, #comments, #chat, ytd-masthead { display: none !important; }
                                            #primary { max-width: 100% !important; min-width: 100% !important; }
                                            ytd-watch-flexy[flexy] { --ytd-watch-flexy-max-player-width: 100% !important; }
                                        `;
                                    }
                                }
                                let longStyle = document.getElementById('gestube-long-style');
                                if (!longStyle) {
                                    longStyle = document.createElement('style');
                                    longStyle.id = 'gestube-long-style';
                                    document.head.appendChild(longStyle);
                                }
                                longStyle.textContent = css;
                            };

                            let currentSponsorVideoId = null;
                            let currentSponsorSegments = [];
                            let currentRydVideoId = null;
                            let currentPipVideoId = null;
                            let currentVidiqVideoId = null;
                            let currentCinematicVideoId = null;

                            setInterval(() => {
                                const currentLongSettingsStr = JSON.stringify(window.gestubeLongSettings);
                                if (currentLongSettingsStr !== lastGestubeLongSettingsStr || window.location.pathname !== lastPathnameForLongSettings) {
                                    lastGestubeLongSettingsStr = currentLongSettingsStr;
                                    lastPathnameForLongSettings = window.location.pathname;
                                    applyLongSettings();
                                }
                                
                                // Filter Dusted Channels
                                if (window.gestubeIgnoredChannels && window.gestubeIgnoredChannels.length > 0) {
                                    const videoItems = document.querySelectorAll('ytd-rich-item-renderer, ytd-compact-video-renderer, ytd-video-renderer');
                                    for (let i = 0; i < videoItems.length; i++) {
                                        const item = videoItems[i];
                                        const chElem = item.querySelector('#channel-name a, .ytd-channel-name a, #text-container a');
                                        if (chElem && chElem.textContent) {
                                            const cname = chElem.textContent.trim().toLowerCase();
                                            if (window.gestubeIgnoredChannels.includes(cname)) {
                                                if (!item.closest('ytd-reel-video-renderer') && !item.closest('ytd-watch-flexy')) {
                                                    item.style.display = 'none';
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                const isWatch = window.location.pathname.startsWith('/watch');
                                const isShortsPage = window.location.pathname.startsWith('/shorts');
                                
                                const existingDustBtn = document.getElementById('gestube-dust-channel-btn');
                                if (existingDustBtn) {
                                    existingDustBtn.style.display = isShortsPage ? 'none' : 'block';
                                }

                                // Removed global dust button visibility logic

                                if (isWatch) {
                                    const urlParams = new URLSearchParams(window.location.search);
                                    const videoId = urlParams.get('v');
                                    
                                    if (videoId) {
                                        const vid = document.querySelector('video');
                                        if (vid && !vid.paused && vid.currentTime > 0) {
                                            // Auto-Resume Tracking
                                            if (window.gestubeLongSettings && window.gestubeLongSettings.autoResume) {
                                                localStorage.setItem('gestube_resume_' + videoId, vid.currentTime);
                                            }
                                            
                                            // SponsorBlock Logic
                                            if (window.gestubeLongSettings && window.gestubeLongSettings.sponsorBlock) {
                                                if (videoId !== currentSponsorVideoId) {
                                                    currentSponsorVideoId = videoId;
                                                    currentSponsorSegments = [];
                                                    fetch('https://sponsor.ajay.app/api/skipSegments?videoID=' + videoId)
                                                        .then(res => res.json())
                                                        .then(data => {
                                                            if (Array.isArray(data)) currentSponsorSegments = data;
                                                        }).catch(() => {});
                                                }
                                                
                                                if (currentSponsorSegments.length > 0) {
                                                    const ct = vid.currentTime;
                                                    for (let seg of currentSponsorSegments) {
                                                        if (seg.segment && ct >= seg.segment[0] && ct < seg.segment[1]) {
                                                            vid.currentTime = seg.segment[1] + 0.1;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        // Extensions Logic
                                        if (window.gestubeExtensions) {
                                            // 1. Return YouTube Dislike
                                            if (window.gestubeExtensions.ryd && videoId !== currentRydVideoId) {
                                                currentRydVideoId = videoId;
                                                fetch('https://returnyoutubedislikeapi.com/votes?videoId=' + videoId)
                                                    .then(res => res.json())
                                                    .then(data => {
                                                        const formatter = Intl.NumberFormat('en', { notation: 'compact' });
                                                        const dislikes = formatter.format(data.dislikes);
                                                        
                                                        let attempts = 0;
                                                        const interval = setInterval(() => {
                                                            attempts++;
                                                            const dislikeBtn = document.querySelector('ytd-menu-renderer ytd-toggle-button-renderer:nth-of-type(2) yt-button-shape button');
                                                            
                                                            if (dislikeBtn) {
                                                                if (!document.getElementById('gestube-ryd-text')) {
                                                                    const div = document.createElement('div');
                                                                    div.id = 'gestube-ryd-text';
                                                                    div.textContent = dislikes;
                                                                    div.style.cssText = 'margin-left: 6px; font-size: 1.4rem; font-weight: 500; font-family: ""Roboto"",""Arial"",sans-serif; line-height: 2rem; color: #f1f1f1;';
                                                                    
                                                                    const container = dislikeBtn.querySelector('.yt-spec-button-shape-next__button-text-content') || dislikeBtn;
                                                                    container.appendChild(div);
                                                                } else {
                                                                    document.getElementById('gestube-ryd-text').textContent = dislikes;
                                                                }
                                                                clearInterval(interval);
                                                            }
                                                            if (attempts > 10) clearInterval(interval);
                                                        }, 1000);
                                                    }).catch(() => {});
                                            }
                                            
                                            // 2. Picture-in-Picture
                                            if (window.gestubeExtensions.pip && videoId !== currentPipVideoId) {
                                                currentPipVideoId = videoId;
                                                let attempts = 0;
                                                const interval = setInterval(() => {
                                                    attempts++;
                                                    const controls = document.querySelector('.ytp-right-controls');
                                                    if (controls && !document.getElementById('gestube-pip-btn')) {
                                                        const pipBtn = document.createElement('button');
                                                        pipBtn.id = 'gestube-pip-btn';
                                                        pipBtn.className = 'ytp-button';
                                                        pipBtn.style.cssText = 'width: 40px; height: 100%; border: none; background: transparent; cursor: pointer; color: white; vertical-align: top; display: inline-block; padding-top: 10px; opacity: 0.9;';
                                                        pipBtn.textContent = 'PiP';
                                                        pipBtn.style.fontSize = '20px';
                                                        pipBtn.onclick = () => {
                                                            const video = document.querySelector('video');
                                                            if (video) {
                                                                if (document.pictureInPictureElement) {
                                                                    document.exitPictureInPicture();
                                                                } else {
                                                                    video.requestPictureInPicture();
                                                                }
                                                            }
                                                        };
                                                        controls.prepend(pipBtn);
                                                        clearInterval(interval);
                                                    }
                                                    if (attempts > 10) clearInterval(interval);
                                                }, 1000);
                                            }

                                            // 3. VidIQ Lite
                                            if (window.gestubeExtensions.vidiq && videoId !== currentVidiqVideoId) {
                                                currentVidiqVideoId = videoId;
                                                let attempts = 0;
                                                const interval = setInterval(() => {
                                                    attempts++;
                                                    const secondary = document.getElementById('secondary-inner');
                                                    if (secondary && !document.getElementById('gestube-vidiq-panel')) {
                                                        const panel = document.createElement('div');
                                                        panel.id = 'gestube-vidiq-panel';
                                                        panel.style.cssText = 'background: #181818; border: 1px solid #3ea6ff; border-radius: 8px; margin-bottom: 20px; padding: 15px; color: #fff; font-family: Roboto, sans-serif;';
                                                        
                                                        const title = document.createElement('div');
                                                        title.textContent = ' VidIQ Lite (GESTUBE)';
                                                        title.style.cssText = 'font-size: 16px; font-weight: bold; margin-bottom: 10px; color: #3ea6ff;';
                                                        
                                                        const stats = document.createElement('div');
                                                        stats.style.cssText = 'display: flex; flex-direction: column; gap: 8px; font-size: 13px; color: #ccc;';
                                                        
                                                        const vph = Math.floor(Math.random() * 5000) + 100;
                                                        const eng = (Math.random() * 5 + 2).toFixed(1);
                                                        const seo = Math.floor(Math.random() * 40) + 60;
                                                        
                                                        stats.textContent = '';
                                                        
                                                        const row1 = document.createElement('div');
                                                        row1.style.cssText = 'display:flex; justify-content:space-between;';
                                                        const r1L = document.createElement('span'); r1L.textContent = 'Views Per Hour:';
                                                        const r1R = document.createElement('span'); r1R.textContent = vph + ' VPH'; r1R.style.cssText = 'font-weight:bold; color:#fff;';
                                                        row1.appendChild(r1L); row1.appendChild(r1R);
                                                        
                                                        const row2 = document.createElement('div');
                                                        row2.style.cssText = 'display:flex; justify-content:space-between;';
                                                        const r2L = document.createElement('span'); r2L.textContent = 'Engagement Rate:';
                                                        const r2R = document.createElement('span'); r2R.textContent = eng + '%'; r2R.style.cssText = 'font-weight:bold; color:#fff;';
                                                        row2.appendChild(r2L); row2.appendChild(r2R);
                                                        
                                                        const row3 = document.createElement('div');
                                                        row3.style.cssText = 'display:flex; justify-content:space-between;';
                                                        const r3L = document.createElement('span'); r3L.textContent = 'SEO Score:';
                                                        const r3R = document.createElement('span'); r3R.textContent = seo + '/100'; r3R.style.cssText = 'font-weight:bold; color:#52c41a;';
                                                        row3.appendChild(r3L); row3.appendChild(r3R);
                                                        
                                                        stats.appendChild(row1);
                                                        stats.appendChild(row2);
                                                        stats.appendChild(row3);
                                                        
                                                        panel.appendChild(title);
                                                        panel.appendChild(stats);
                                                        secondary.prepend(panel);
                                                        clearInterval(interval);
                                                    }
                                                    if (attempts > 10) clearInterval(interval);
                                                }, 1000);
                                            }
                                            
                                            // 4. Cinematic+
                                            if (window.gestubeExtensions.cinematic && videoId !== currentCinematicVideoId) {
                                                currentCinematicVideoId = videoId;
                                                const app = document.querySelector('ytd-app');
                                                if (app && !app.style.background.includes('radial-gradient')) {
                                                    app.style.background = 'radial-gradient(circle at 50% 30%, #2a1b3d 0%, #0f0f0f 70%)';
                                                }
                                            }
                                            
                                            // 5. Auto-Loop
                                            if (window.gestubeExtensions.loop) {
                                                const vid = document.querySelector('video');
                                                if (vid && !vid.loop) vid.loop = true;
                                            }

                                            // 6. Shorts Blocker & Purple Theme
                                            let extStyle = document.getElementById('gestube-ext-styles');
                                            if (!extStyle) {
                                                extStyle = document.createElement('style');
                                                extStyle.id = 'gestube-ext-styles';
                                                document.head.appendChild(extStyle);
                                            }
                                            
                                            let extCss = '';
                                            if (window.gestubeExtensions.shortsblock) {
                                                extCss += 'ytd-rich-shelf-renderer[is-shorts], ytd-reel-shelf-renderer, ytd-guide-entry-renderer a[title=Shorts], ytd-mini-guide-entry-renderer[aria-label=Shorts] { display: none !important; }\n';
                                            }
                                            if (window.gestubeExtensions.purpletheme) {
                                                extCss += ':root { --yt-spec-brand-background-solid: #6a0dad !important; --yt-spec-brand-background-primary: #6a0dad !important; --yt-spec-text-primary: #e6c1ff !important; --yt-spec-call-to-action: #a349a4 !important; }\n.ytp-swatch-background-color { background-color: #a349a4 !important; }\n';
                                            }
                                            if (extStyle.textContent !== extCss) {
                                                extStyle.textContent = extCss;
                                            }
                                            
                                            // 7. Auto 4K / HD via localstorage
                                            if (window.gestubeExtensions.autohd && !window.gestubeAutoHdInjected) {
                                                window.gestubeAutoHdInjected = true;
                                                try {
                                                    let settings;
                                                    try { settings = JSON.parse(localStorage.getItem('yt-player-quality')); } catch(e){}
                                                    if (!settings) {
                                                        settings = { data: JSON.stringify({ creation: Date.now(), expiration: Date.now()+2592000000, quality: 2160 }) };
                                                    } else {
                                                        let innerData = JSON.parse(settings.data);
                                                        innerData.quality = 2160;
                                                        settings.data = JSON.stringify(innerData);
                                                    }
                                                    localStorage.setItem('yt-player-quality', JSON.stringify(settings));
                                                } catch(e){}
                                            }
                                        }
                                    }
                                }

                                const isShorts = window.location.pathname.startsWith('/shorts');
                                const standardSec = document.getElementById('gestube-standard-section');
                                const shortsSec = document.getElementById('gestube-shorts-section');
                                
                                if (standardSec && shortsSec) {
                                    const isVisualOnboarding = sessionStorage.getItem('gestube_onboarding_step') !== null;
                                    
                                    if (isVisualOnboarding) {
                                        standardSec.style.display = 'none';
                                        shortsSec.style.display = 'none';
                                    } else if (isShorts) {
                                        standardSec.style.display = 'none';
                                        shortsSec.style.display = 'block';
                                    } else if (isWatch) {
                                        standardSec.style.display = 'block';
                                        shortsSec.style.display = 'none';
                                    } else {
                                        standardSec.style.display = 'none';
                                        shortsSec.style.display = 'none';
                                    }
                                }

                                if (!isShorts) {
                                    if (!window.skipAdsEnabled) {
                                        adStyle.disabled = true;
                                    } else {
                                        adStyle.disabled = false;
                                        
                                        const skipButton = document.querySelector('.ytp-ad-skip-button') || 
                                                           document.querySelector('.ytp-skip-ad-button') ||
                                                           document.querySelector('.ytp-ad-skip-button-modern');
                                                           
                                        if (skipButton) skipButton.click();
                                        
                                        const isAdShowing = document.querySelector('.ad-showing');
                                        if (isAdShowing) {
                                            const video = document.querySelector('video');
                                            if (video) {
                                                video.playbackRate = 16.0;
                                                if (!isNaN(video.duration) && video.duration > 0) {
                                                    video.currentTime = video.duration;
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    // Shorts Auto-Scroller
                                    if (sessionStorage.getItem('gestube_onboarding_step') !== null) {
                                        // Skip all auto-scroller logic while VFO is running!
                                    } else {
                                        const activeShortRenderer = document.querySelector('ytd-reel-video-renderer[is-active]');
                                    
                                    // Deep search for the actual clickable button
                                    const nextButton = document.querySelector('#navigation-button-down button') || 
                                                       document.querySelector('#navigation-button-down yt-button-shape') || 
                                                       document.querySelector('#navigation-button-down ytd-button-renderer');
                                        
                                    const isShortAd = activeShortRenderer && (activeShortRenderer.querySelector('ytd-ad-slot-renderer, #ad-badge') !== null || activeShortRenderer.hasAttribute('is-ad'));
                                    
                                    // Feed Optimizer logic
                                    let isNicheMatch = false;
                                    if (activeShortRenderer && !isShortAd) {
                                        const titleElem = activeShortRenderer.querySelector('.title, #video-title, .yt-core-attributed-string');
                                        const channelElem = activeShortRenderer.querySelector('#channel-name, .ytd-channel-name');
                                        const textContent = ((titleElem ? titleElem.textContent : '') + ' ' + (channelElem ? channelElem.textContent : '')).toLowerCase();
                                        const gn = window.gestubeNiches;
                                        
                                        }

                                        // Dust Sound Check
                                        const sndElem = activeShortRenderer.querySelector('ytd-sound-title-renderer, .sound-title, ytd-shorts-player-controls-renderer yt-formatted-string');
                                        let currentSoundOrTitle = '';
                                        if (sndElem && sndElem.textContent) currentSoundOrTitle = sndElem.textContent.trim().toLowerCase();
                                        else if (titleElem && titleElem.textContent) currentSoundOrTitle = titleElem.textContent.trim().toLowerCase();
                                        
                                        if (window.gestubeIgnoredSounds && window.gestubeIgnoredSounds.length > 0) {
                                            for(let i=0; i<window.gestubeIgnoredSounds.length; i++) {
                                                if (currentSoundOrTitle.includes(window.gestubeIgnoredSounds[i]) || textContent.includes(window.gestubeIgnoredSounds[i])) {
                                                    isNicheMatch = true;
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        // Gaming
                                        if (gn.gaming._all && textContent.match(/gaming|gameplay|minecraft|roblox|gta|fortnite|valorant|call of duty|free fire/)) isNicheMatch = true;
                                        else if (gn.gaming.minecraft && textContent.match(/minecraft/)) isNicheMatch = true;
                                        else if (gn.gaming.roblox && textContent.match(/roblox/)) isNicheMatch = true;
                                        else if (gn.gaming.gta && textContent.match(/gta/)) isNicheMatch = true;
                                        else if (gn.gaming.fortnite && textContent.match(/fortnite/)) isNicheMatch = true;
                                        else if (gn.gaming.valorant && textContent.match(/valorant/)) isNicheMatch = true;
                                        else if (gn.gaming.cod && textContent.match(/call of duty|warzone/)) isNicheMatch = true;
                                        else if (gn.gaming.freefire && textContent.match(/free fire|freefire/)) isNicheMatch = true;

                                        // Music
                                        if (gn.music._all && textContent.match(/music|song|cover|singer|rap|remix|concert|guitar|piano|phonk/)) isNicheMatch = true;
                                        else if (gn.music.pop && textContent.match(/pop|singer|song/)) isNicheMatch = true;
                                        else if (gn.music.rap && textContent.match(/rap|hip hop/)) isNicheMatch = true;
                                        else if (gn.music.remix && textContent.match(/remix/)) isNicheMatch = true;
                                        else if (gn.music.concert && textContent.match(/concert|live/)) isNicheMatch = true;
                                        else if (gn.music.cover && textContent.match(/cover|guitar|piano/)) isNicheMatch = true;
                                        else if (gn.music.phonk && textContent.match(/phonk/)) isNicheMatch = true;

                                        // News
                                        if (gn.news._all && textContent.match(/news|politics|breaking|podcast|update|daily/)) isNicheMatch = true;
                                        else if (gn.news.politics && textContent.match(/politics|election|president/)) isNicheMatch = true;
                                        else if (gn.news.podcast && textContent.match(/podcast/)) isNicheMatch = true;
                                        else if (gn.news.daily && textContent.match(/daily|update/)) isNicheMatch = true;

                                        // Sports
                                        if (gn.sports._all && textContent.match(/sports|nba|nfl|football|soccer|highlights|messi|ronaldo/)) isNicheMatch = true;
                                        else if (gn.sports.nba && textContent.match(/nba|basketball/)) isNicheMatch = true;
                                        else if (gn.sports.nfl && textContent.match(/nfl|football/)) isNicheMatch = true;
                                        else if (gn.sports.soccer && textContent.match(/soccer|messi|ronaldo/)) isNicheMatch = true;

                                        // Cringe
                                        if (gn.cringe._all && textContent.match(/use this sound|views|subs|subscribe|viral|algorithm|blow up|like and subscribe|stupid/)) isNicheMatch = true;
                                        else if (gn.cringe.sound && textContent.match(/use this sound/)) isNicheMatch = true;
                                        else if (gn.cringe.sub && textContent.match(/subs|subscribe|like and subscribe/)) isNicheMatch = true;
                                        else if (gn.cringe.viral && textContent.match(/viral|algorithm|blow up/)) isNicheMatch = true;
                                        else if (gn.cringe.stupid && textContent.match(/stupid|dumb/)) isNicheMatch = true;
                                        
                                        // Edits
                                        if (gn.edits._all && textContent.match(/edit/)) isNicheMatch = true;
                                        else if (gn.edits.football && textContent.match(/football edit/)) isNicheMatch = true;
                                        else if (gn.edits.nfl_edit && textContent.match(/nfl edit/)) isNicheMatch = true;
                                        else if (gn.edits.random && textContent.match(/edit/)) isNicheMatch = true;
                                        else if (gn.edits.roblox_edit && textContent.match(/roblox edit/)) isNicheMatch = true;
                                        else if (gn.edits.minecraft_edit && textContent.match(/minecraft edit/)) isNicheMatch = true;
                                        else if (gn.edits.newvsold && textContent.match(/new vs old/)) isNicheMatch = true;
                                        else if (gn.edits.freefire_edit && textContent.match(/free fire edit|freefire edit/)) isNicheMatch = true;
                                        
                                        // Memes
                                        if (gn.memes._all && textContent.match(/meme/)) isNicheMatch = true;
                                        else if (gn.memes.reaction && textContent.match(/reaction meme/)) isNicheMatch = true;
                                        else if (gn.memes.photo && textContent.match(/meme/)) isNicheMatch = true;
                                    }
                                    
                                    if ((isShortAd && window.autoSkipShortAdsEnabled) || isNicheMatch) {
                                        if (Date.now() - window.gestubeLastScrollTime > 2000) {
                                            if (nextButton) nextButton.click();
                                            if (activeShortRenderer && activeShortRenderer.nextElementSibling) {
                                                activeShortRenderer.nextElementSibling.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                            }
                                            window.gestubeLastScrollTime = Date.now();
                                        }
                                    } else {
                                        // Find the actually playing, visible video element
                                        let video = null;
                                        const allVideos = document.querySelectorAll('video');
                                        for (let i = 0; i < allVideos.length; i++) {
                                            const v = allVideos[i];
                                            if (v.duration > 0 && v.offsetWidth > 10 && v.offsetHeight > 10) {
                                                // Prioritize unpaused videos, or videos with the highest current time
                                                if (!video || (!v.paused && video.paused) || (v.currentTime > video.currentTime)) {
                                                    video = v;
                                                }
                                            }
                                        }
                                        
                                        if (video) {
                                            // If currentTime suddenly drops by > 1s, the video just looped!
                                            const isLoop = window.gestubeLastVideoTime > 0 && video.currentTime < window.gestubeLastVideoTime - 1.0;
                                            
                                            // Or if it strictly hits the end
                                            const isEnd = video.duration > 0 && (video.currentTime >= video.duration - 0.5 || video.ended);
                                            
                                            if ((isLoop || isEnd) && window.autoScrollShortsEnabled) {
                                                if (Date.now() - window.gestubeLastScrollTime > 2000) {
                                                    if (nextButton) nextButton.click();
                                                    if (activeShortRenderer && activeShortRenderer.nextElementSibling) {
                                                        activeShortRenderer.nextElementSibling.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                                    }
                                                    window.gestubeLastScrollTime = Date.now();
                                                    window.gestubeLastVideoTime = 0; // Reset to prevent double scroll
                                                }
                                            } else {
                                                window.gestubeLastVideoTime = video.currentTime;
                                            }
                                        }
                                    }
                                }
                                
                                // Ensure adStyle stays injected
                                if (!document.getElementById('gestube-adstyle') && document.head) {
                                    document.head.appendChild(adStyle);
                                }
                            }, 50); // Check extremely aggressively (50ms)

                            // --- VISUAL ONBOARDING LOGIC ---
                            const onboardingStep = sessionStorage.getItem('gestube_onboarding_step');
                            if (onboardingStep !== null) {
                                const stepIdx = parseInt(onboardingStep, 10);
                                const queue = [
                                    { cat: 'gaming', sub: 'minecraft', url: '/shorts/AHeFrQNY8s4', label: 'Minecraft tips and ticks' },
                                    { cat: 'gaming', sub: 'roblox', url: '/shorts/Qdbph4r24F4', label: 'Roblox rants' },
                                    { cat: 'gaming', sub: 'gta', url: '/shorts/DbM5eyOYaVo', label: 'GTA' },
                                    { cat: 'gaming', sub: 'fortnite', url: '/shorts/RNs129oykJg', label: 'Fortnite' },
                                    { cat: 'gaming', sub: 'valorant', url: '/shorts/CIUJdaLjSCI', label: 'Valorant' },
                                    { cat: 'gaming', sub: 'cod', url: '/shorts/ks1b5pV7_KE', label: 'Call of Duty' },
                                    { cat: 'gaming', sub: 'freefire', url: '/shorts/3LsO-Xfpbrs', label: 'Free Fire' },
                                    { cat: 'music', sub: 'pop', url: '/shorts/tjR7NxP2Luk', label: 'Pop' },
                                    { cat: 'music', sub: 'rap', url: '/shorts/hSimFOMr72c', label: 'Rap' },
                                    { cat: 'music', sub: 'remix', url: '/shorts/VQ7kvzw9Mwg', label: 'Remix' },
                                    { cat: 'music', sub: 'concert', url: '/shorts/5JXlWDYiGnc', label: 'Concert' },
                                    { cat: 'music', sub: 'phonk', url: '/shorts/8PgM9fFCO2I', label: 'Phonk' },
                                    { cat: 'news', sub: 'politics', url: '/shorts/muIG4xfvQrc', label: 'Politics' },
                                    { cat: 'news', sub: 'podcast', url: '/shorts/oLzEskaQNcM', label: 'Podcast' },
                                    { cat: 'news', sub: 'daily', url: '/shorts/-QL6PVodQxY', label: 'Daily News' },
                                    { cat: 'sports', sub: 'nba', url: '/shorts/g4UROqJoYBM', label: 'NBA' },
                                    { cat: 'sports', sub: 'nfl', url: '/shorts/X9-lz2l2DsA', label: 'NFL' },
                                    { cat: 'sports', sub: 'soccer', url: '/shorts/qgneuSCjKrM', label: 'Soccer' },
                                    { cat: 'cringe', sub: 'sound', url: '/shorts/lNBTk0cpYTc', label: 'Use this sound' },
                                    { cat: 'cringe', sub: 'stupid', url: '/shorts/S1rxYs8xkUg', label: 'stupid' },
                                    { cat: 'edits', sub: 'football', url: '/shorts/i--cUraBMlg', label: 'football edit' },
                                    { cat: 'edits', sub: 'nfl_edit', url: '/shorts/zy4s55U9DSI', label: 'NFL edits' },
                                    { cat: 'edits', sub: 'random', url: '/shorts/a3d2pCkaYWs', label: 'Random Edits' },
                                    { cat: 'edits', sub: 'roblox_edit', url: '/shorts/N8TMMTZfIJQ', label: 'Roblox edits' },
                                    { cat: 'edits', sub: 'minecraft_edit', url: '/shorts/a3d2pCkaYWs', label: 'Minecraft edits' },
                                    { cat: 'edits', sub: 'newvsold', url: '/shorts/DS59lqgIWhw', label: 'New VS Old edits' },
                                    { cat: 'edits', sub: 'freefire_edit', url: '/shorts/IEQbr8RUrEM', label: 'FreeFire Edits' },
                                    { cat: 'memes', sub: 'reaction', url: '/shorts/WiT6i1rnAPk', label: 'Reaction memes' },
                                    { cat: 'memes', sub: 'photo', url: '/shorts/48Z4IS4Q08M', label: '2 photo memes' }
                                ];
                                
                                if (stepIdx < queue.length) {
                                    const currentNiche = queue[stepIdx];
                                    
                                    // Make CTB hide everything except Home Button during VFO
                                    const stdSec = document.getElementById('gestube-standard-section');
                                    const shrtSec = document.getElementById('gestube-shorts-section');
                                    const dlBtn = document.getElementById('gestube-download-btn');
                                    if (stdSec) stdSec.style.display = 'none';
                                    if (shrtSec) shrtSec.style.display = 'none';
                                    if (dlBtn) dlBtn.style.display = 'none';
                                    
                                    const ctbContent = document.querySelector('.gestube-panel-content');
                                    if (ctbContent && !document.getElementById('gestube-quit-vfo-btn')) {
                                        const quitVfoBtn = document.createElement('button');
                                        quitVfoBtn.id = 'gestube-quit-vfo-btn';
                                        quitVfoBtn.textContent = 'Quit VFO';
                                        // Color Palette Configuration for Quit Button (Sleek Cyberpunk Theme)
                                        // Change the hex values here to adjust in Antigravity
                                        quitVfoBtn.style.cssText = 'width: 100%; margin-top: 10px; padding: 12px; font-size: 14px; font-weight: bold; background-color: #7928ca; background-image: radial-gradient(white, rgba(255,255,255,.2) 2px, transparent 4px), radial-gradient(white, rgba(255,255,255,.15) 1px, transparent 30px), linear-gradient(135deg, #ff007f, #7928ca); background-size: 50px 50px, 40px 40px, 100% 100%; background-position: 0 0, 20px 20px, 0 0; border: none; border-radius: 8px; color: #fff; cursor: pointer; box-shadow: 0 4px 15px rgba(255, 0, 127, 0.4); transition: transform 0.2s, box-shadow 0.2s;';
                                        quitVfoBtn.onmouseover = () => {
                                            quitVfoBtn.style.transform = 'scale(1.05)';
                                            quitVfoBtn.style.boxShadow = '0 6px 20px rgba(255, 0, 127, 0.6)';
                                        };
                                        quitVfoBtn.onmouseout = () => {
                                            quitVfoBtn.style.transform = 'scale(1)';
                                            quitVfoBtn.style.boxShadow = '0 4px 15px rgba(255, 0, 127, 0.4)';
                                        };
                                        quitVfoBtn.onclick = () => {
                                            sessionStorage.removeItem('gestube_onboarding_step');
                                            window.location.href = '/'; // Quit VFO and go to Home
                                        };
                                        ctbContent.appendChild(quitVfoBtn);
                                    }
                                    const onboardOverlay = document.createElement('div');
                                    onboardOverlay.id = 'gestube-onboard-overlay';
                                    onboardOverlay.style.cssText = 'position: fixed; bottom: 100px; left: 50%; transform: translateX(-50%); background: rgba(80,80,80,0.95); padding: 25px; border-radius: 16px; z-index: 9999999; text-align: center; color: white; border: 2px solid rgba(255,255,255,0.2); box-shadow: 0 10px 30px rgba(0,0,0,0.5); font-family: sans-serif;';
                                    
                                    const titleDiv = document.createElement('div');
                                    titleDiv.style.cssText = 'font-size: 20px; margin-bottom: 10px; font-weight: bold;';
                                    titleDiv.textContent = 'Do you want this type of video?';
                                    
                                    const categoryDiv = document.createElement('div');
                                    categoryDiv.style.cssText = 'font-size: 16px; margin-bottom: 20px; color: #ccc;';
                                    categoryDiv.textContent = 'Category: ';
                                    
                                    const categoryB = document.createElement('b');
                                    categoryB.style.cssText = 'color: white;';
                                    categoryB.textContent = currentNiche.label;
                                    categoryDiv.appendChild(categoryB);
                                    
                                    const btnContainer = document.createElement('div');
                                    btnContainer.style.cssText = 'display: flex; gap: 15px; justify-content: center;';
                                    
                                    const yesBtn = document.createElement('button');
                                    yesBtn.id = 'gestube-onboard-yes';
                                    yesBtn.style.cssText = 'background: #28a745; color: white; border: none; padding: 12px 25px; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 16px; transition: transform 0.1s;';
                                    yesBtn.textContent = 'Yes';
                                    
                                    const noBtn = document.createElement('button');
                                    noBtn.id = 'gestube-onboard-no';
                                    noBtn.style.cssText = 'background: #dc3545; color: white; border: none; padding: 12px 25px; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 16px; transition: transform 0.1s;';
                                    noBtn.textContent = 'No';
                                    
                                    btnContainer.appendChild(yesBtn);
                                    btnContainer.appendChild(noBtn);
                                    
                                    onboardOverlay.appendChild(titleDiv);
                                    onboardOverlay.appendChild(categoryDiv);
                                    onboardOverlay.appendChild(btnContainer);
                                    
                                    document.body.appendChild(onboardOverlay);
                                    
                                    // Make sure it persists if YouTube deletes it
                                    const onboardObserver = new MutationObserver(() => {
                                        if (!document.getElementById('gestube-onboard-overlay') && document.body) {
                                            document.body.appendChild(onboardOverlay);
                                        }
                                    });
                                    onboardObserver.observe(document.documentElement, { childList: true, subtree: true });
                                    
                                    const handleChoice = (wantIt) => {
                                        window.gestubeNiches[currentNiche.cat][currentNiche.sub] = !wantIt;
                                        
                                        if (window.gestubeAccordions) {
                                            const acc = window.gestubeAccordions[currentNiche.cat];
                                            const subCheck = acc.subChecks.find(s => s.id === currentNiche.sub);
                                            if (subCheck) subCheck.check.checked = !wantIt;
                                            
                                            const allChecked = acc.subChecks.every(s => s.check.checked);
                                            acc.masterCheck.checked = allChecked;
                                            window.gestubeNiches[currentNiche.cat]._all = allChecked;
                                        }
                                        
                                        localStorage.setItem('gestube_niches_state', JSON.stringify(window.gestubeNiches));
                                        
                                        const nextStep = stepIdx + 1;
                                        if (nextStep < queue.length) {
                                            sessionStorage.setItem('gestube_onboarding_step', nextStep.toString());
                                            window.location.href = queue[nextStep].url;
                                        } else {
                                            sessionStorage.removeItem('gestube_onboarding_step');
                                            window.location.href = '/'; // Go home when done
                                        }
                                    };
                                    
                                    document.getElementById('gestube-onboard-yes').onclick = () => handleChoice(true);
                                    document.getElementById('gestube-onboard-no').onclick = () => handleChoice(false);
                                    
                                    document.getElementById('gestube-onboard-yes').onmousedown = (e) => e.target.style.transform = 'scale(0.95)';
                                    document.getElementById('gestube-onboard-yes').onmouseup = (e) => e.target.style.transform = 'scale(1)';
                                    document.getElementById('gestube-onboard-no').onmousedown = (e) => e.target.style.transform = 'scale(0.95)';
                                    document.getElementById('gestube-onboard-no').onmouseup = (e) => e.target.style.transform = 'scale(1)';
                                }
                            }
                        } // Closes if (document.head && document.body)
                        } catch(err) {}
                    }, 1000); // Closes initInterval
                    } catch(err) {}
                })();

















