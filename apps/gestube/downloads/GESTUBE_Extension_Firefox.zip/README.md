# GESTUBE Browser Extension (All Browsers Supported)

This extension brings the full **GESTUBE** power (smart sidebar controller, auto ad skipping, dust channels, auto-scroll shorts, and feed filters) directly to your desktop or mobile browser.

---

## 🚀 How to Install in Any Browser:

### 1. Google Chrome / Brave / Opera / Vivaldi
1. Open your browser and navigate to `chrome://extensions/` (or `brave://extensions/`, `opera://extensions/`).
2. Toggle on **"Developer mode"** (usually in the top-right corner).
3. Click **"Load unpacked"**.
4. Select the folder:
   `C:\Users\Admin\Desktop\Coding files and folders\NEW\GESTUBE_Extension`
5. Done! Pin GESTUBE and open [YouTube](https://www.youtube.com).

---

### 2. Microsoft Edge
1. Navigate to `edge://extensions/`.
2. Turn on the **"Developer mode"** toggle in the left sidebar.
3. Click **"Load unpacked"**.
4. Select the folder:
   `C:\Users\Admin\Desktop\Coding files and folders\NEW\GESTUBE_Extension`
5. Done!

---

### 3. Mozilla Firefox
1. Open Firefox and type `about:debugging#/runtime/this-firefox` in the URL bar.
2. Click **"Load Temporary Add-on..."**.
3. Navigate to `C:\Users\Admin\Desktop\Coding files and folders\NEW\GESTUBE_Extension` and select `manifest.json`.
4. Done!

---

### 4. Kiwi Browser / Orion (Android / iOS with extensions)
1. In Kiwi Browser on Android, open the menu (three dots) -> **Extensions**.
2. Enable **Developer mode**.
3. Tap **+(from .zip / .crx / .folder)** or load the `GESTUBE_Extension` folder/zip.
4. GESTUBE will run seamlessly on mobile web YouTube as well.
